import { useEffect, useState } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { BountyDifficulty, SkillCategory } from '@prisma/client'
import { EditBountyDialog } from '@/components/EditBountyDialog'
import { toast } from '@/components/ui/use-toast'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

type Bounty = {
  id: string
  title: string
  description: string
  difficulty: BountyDifficulty
  category: SkillCategory
  monetaryReward: number
  xpReward: number
  coinReward: number
  deadline: string
  poster: {
    name: string
    studioProfile: {
      studioName: string
      verified: boolean
    }
  }
}

export default function BountiesPage() {
  const { user } = useAuth()
  const [bounties, setBounties] = useState<Bounty[]>([])
  const [loading, setLoading] = useState(true)
  const [userRole, setUserRole] = useState<'creator' | 'studio' | null>(null)
  const [filter, setFilter] = useState({
    difficulty: 'all',
    category: 'all',
  })

  useEffect(() => {
    const fetchUserRole = async () => {
      if (!user) return
      try {
        const response = await fetch('/api/profile')
        if (response.ok) {
          const data = await response.json()
          setUserRole(data.studioProfile ? 'studio' : 'creator')
        }
      } catch (error) {
        console.error('Error fetching user role:', error)
      }
    }
    fetchUserRole()
  }, [user])

  useEffect(() => {
    const fetchBounties = async () => {
      try {
        const response = await fetch('/api/bounties')
        const data = await response.json()
        setBounties(data)
      } catch (error) {
        console.error('Error fetching bounties:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchBounties()
  }, [])

  const filteredBounties = bounties.filter((bounty) => {
    if (filter.difficulty !== 'all' && bounty.difficulty !== filter.difficulty) {
      return false
    }
    if (filter.category !== 'all' && bounty.category !== filter.category) {
      return false
    }
    return true
  })

  const getDifficultyColor = (difficulty: BountyDifficulty) => {
    switch (difficulty) {
      case 'EASY':
        return 'bg-green-100 text-green-800'
      case 'MEDIUM':
        return 'bg-yellow-100 text-yellow-800'
      case 'HARD':
        return 'bg-orange-100 text-orange-800'
      case 'LEGENDARY':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  if (loading) {
    return (
      <div className="container mx-auto p-6 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-4 w-2/3" />
                <Skeleton className="h-4 w-1/2" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <Button
        variant="outline"
        onClick={() => window.location.href = '/dashboard'}
        className="mb-4"
      >
        ← Back to Dashboard
      </Button>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h1 className="text-3xl font-bold">Available Bounties</h1>
        <div className="flex gap-4">
          <Select
            value={filter.difficulty}
            onValueChange={(value) =>
              setFilter((prev) => ({ ...prev, difficulty: value }))
            }
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by difficulty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Difficulties</SelectItem>
              <SelectItem value="EASY">Easy</SelectItem>
              <SelectItem value="MEDIUM">Medium</SelectItem>
              <SelectItem value="HARD">Hard</SelectItem>
              <SelectItem value="LEGENDARY">Legendary</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={filter.category}
            onValueChange={(value) =>
              setFilter((prev) => ({ ...prev, category: value }))
            }
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {Object.values(SkillCategory).map((category) => (
                <SelectItem key={category} value={category}>
                  {category.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase())}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredBounties.map((bounty) => (
          <Card key={bounty.id} className="flex flex-col">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>{bounty.title}</CardTitle>
                  <CardDescription>
                    by {bounty.poster.studioProfile.studioName}
                    {bounty.poster.studioProfile.verified && ' ✓'}
                  </CardDescription>
                </div>
                <Badge
                  variant="secondary"
                  className={getDifficultyColor(bounty.difficulty)}
                >
                  {bounty.difficulty.toLowerCase()}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <p className="text-sm text-gray-600 mb-4">{bounty.description}</p>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Reward:</span>
                  <span className="font-medium">
                    ${bounty.monetaryReward} + {bounty.xpReward}XP
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Deadline:</span>
                  <span className="font-medium">
                    {new Date(bounty.deadline).toLocaleDateString()}
                  </span>
                </div>
                {user?.id === bounty.poster.id ? (
                  <div className="flex gap-2 mt-4">
                    <EditBountyDialog
                      bounty={bounty}
                      onBountyUpdated={() => {
                        setLoading(true)
                        fetch('/api/bounties')
                          .then((res) => res.json())
                          .then((data) => setBounties(data))
                          .finally(() => setLoading(false))
                      }}
                    />
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive">Delete Bounty</Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This action cannot be undone. This will permanently delete the bounty.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={async () => {
                              try {
                                const response = await fetch(`/api/bounties?id=${bounty.id}`, {
                                  method: 'DELETE',
                                })
                                
                                if (!response.ok) {
                                  throw new Error('Failed to delete bounty')
                                }

                                toast({
                                  title: 'Success',
                                  description: 'Bounty deleted successfully',
                                })

                                setBounties(bounties.filter(b => b.id !== bounty.id))
                              } catch (error) {
                                toast({
                                  title: 'Error',
                                  description: 'Failed to delete bounty',
                                  variant: 'destructive',
                                })
                              }
                            }}
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                ) : (
                  <Button 
                    className="w-full mt-4" 
                    onClick={() => window.location.href = `/bounties/${bounty.id}`}
                  >
                    View Details
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredBounties.length === 0 && (
        <div className="text-center py-10">
          <h3 className="text-xl font-semibold">No bounties found</h3>
          <p className="text-gray-600">
            Try adjusting your filters or check back later for new bounties
          </p>
        </div>
      )}
    </div>
  )
}