import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { BountyApplicationsManager } from '@/components/BountyApplicationsManager'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { EditBountyDialog } from '@/components/EditBountyDialog'
import { ApplyToBountyDialog } from '@/components/ApplyToBountyDialog'
import { MilestonesManager } from '@/components/MilestonesManager'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { format } from 'date-fns'
import { useToast } from "@/components/ui/use-toast"

interface Bounty {
  id: string
  title: string
  description: string
  posterId: string
  difficulty: string
  status: string
  category: string
  deadline: string
  monetaryReward: number
  coinReward: number
  totalBudget: number
  remainingBudget: number
  requirements: any // Could be string or JSON
  deliverables: string[]
  poster: {
    id: string
    name: string | null
    studioProfile: {
      studioName: string
      verified: boolean
    } | null
    profile: {
      title: string | null
    } | null
  } | null
  milestones: Array<{
    id: string
    title: string
    description: string
    amount: number
    status: string
    dueDate: string
    order: number
  }>
  applications: Array<{
    id: string
    status: string
    applicantId: string
    coverLetter: string
    createdAt: string
  }>
}

export default function BountyDetail() {
  const router = useRouter()
  const { id } = router.query
  const { user, isLoading: authLoading } = useAuth()
  const [bounty, setBounty] = useState<Bounty | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isRoleLoading, setIsRoleLoading] = useState(true)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const { toast } = useToast()
  const [userRole, setUserRole] = useState<'CREATOR' | 'STUDIO' | null>(null)
  const [error, setError] = useState<string | null>(null)

  // Prevent any data loading until auth is ready
  useEffect(() => {
    if (authLoading) {
      setIsLoading(true);
      setIsRoleLoading(true);
    }
  }, [authLoading]);

  useEffect(() => {
    let isMounted = true;

    const loadData = async () => {
      // Wait for router and auth to be ready
      if (!router.isReady || !id) return;
      
      // Reset states
      setIsLoading(true);
      setError(null);

      try {
        // Load bounty data first
        const bountyResponse = await fetch(`/api/bounties/${id}`);
        if (!bountyResponse.ok) {
          const errorData = await bountyResponse.json();
          throw new Error(errorData.message || 'Failed to load bounty details');
        }

        const bountyData = await bountyResponse.json();
        
        if (!bountyData || !bountyData.id) {
          throw new Error('Bounty not found or invalid data received');
        }

        // Only update state if component is still mounted
        if (!isMounted) return;

        // Transform and validate bounty data
        const transformedBounty: Bounty = {
          id: bountyData.id,
          title: bountyData.title || 'Untitled Bounty',
          description: bountyData.description || '',
          posterId: bountyData.posterId || '',
          difficulty: bountyData.difficulty || 'EASY',
          status: bountyData.status || 'OPEN',
          category: bountyData.category || 'OTHER',
          deadline: bountyData.deadline || new Date().toISOString(),
          monetaryReward: Number(bountyData.monetaryReward || 0),
          coinReward: Number(bountyData.coinReward || 0),
          totalBudget: Number(bountyData.totalBudget || 0),
          remainingBudget: Number(bountyData.remainingBudget || 0),
          requirements: bountyData.requirements || '',
          deliverables: Array.isArray(bountyData.deliverables) ? bountyData.deliverables : [],
          poster: bountyData.poster ? {
            id: bountyData.poster.id || '',
            name: bountyData.poster.name || 'Unknown',
            studioProfile: bountyData.poster.studioProfile || null,
            profile: bountyData.poster.profile || null
          } : null,
          milestones: Array.isArray(bountyData.milestones) ? bountyData.milestones.map(m => ({
            id: m.id,
            title: m.title || '',
            description: m.description || '',
            amount: Number(m.amount || 0),
            status: m.status || 'PENDING',
            dueDate: m.dueDate || new Date().toISOString(),
            order: Number(m.order || 0)
          })) : [],
          applications: Array.isArray(bountyData.applications) ? bountyData.applications : []
        };

        setBounty(transformedBounty);

        // Only fetch user role if user is authenticated
        if (user && !authLoading) {
          try {
            const roleResponse = await fetch('/api/profile');
            if (!roleResponse.ok) {
              throw new Error('Failed to fetch user role');
            }
            const roleData = await roleResponse.json();
            
            if (isMounted) {
              setUserRole(roleData.role || null);
            }
          } catch (roleError) {
            console.error('Error fetching user role:', roleError);
            // Don't throw - we can show bounty without role info
          }
        }
      } catch (error) {
        if (!isMounted) return;
        
        const errorMessage = error instanceof Error ? error.message : 'Failed to load bounty data';
        console.error('Error loading data:', error);
        setError(errorMessage);
        toast({
          variant: "destructive",
          title: "Error",
          description: errorMessage,
        });
      } finally {
        if (isMounted) {
          setIsLoading(false);
          setIsRoleLoading(false);
        }
      }
    };

    loadData();

    return () => {
      isMounted = false;
    };
  }, [router.isReady, id, user, authLoading, toast]);

  const fetchUserRole = async () => {
    setIsRoleLoading(true)
    try {
      const response = await fetch('/api/profile')
      if (response.ok) {
        const data = await response.json()
        setUserRole(data.role)
      }
    } catch (error) {
      console.error('Error fetching user role:', error)
    } finally {
      setIsRoleLoading(false)
    }
  }

  const fetchBountyDetails = async () => {
    if (!id) {
      setError('No bounty ID provided');
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(`/api/bounties/${id}`);
      const data = await response.json();
      
      if (!response.ok) {
        console.error('Failed to fetch bounty details:', data);
        setError(data.message || 'Failed to load bounty details');
        toast({
          variant: "destructive",
          title: "Error",
          description: data.message || "Failed to load bounty details",
        });
        return;
      }

      if (!data) {
        setError('Bounty not found');
        toast({
          variant: "destructive",
          title: "Error",
          description: "Bounty not found",
        });
        return;
      }

      setBounty(data);
    } catch (error) {
      console.error('Error fetching bounty details:', error);
      setError('Failed to load bounty details');
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load bounty details",
      });
    } finally {
      setIsLoading(false);
    }
  }

  const handleDelete = async () => {
    try {
      const response = await fetch(`/api/bounties?id=${id}`, {
        method: 'DELETE',
      })
      
      if (response.ok) {
        router.push('/dashboard')
      } else {
        console.error('Failed to delete bounty')
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to delete bounty",
        })
      }
    } catch (error) {
      console.error('Error deleting bounty:', error)
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete bounty",
      })
    }
  }

  const handleAcceptBounty = async () => {
    if (userRole === 'STUDIO') {
      toast({
        variant: "destructive",
        title: "Action not allowed",
        description: "Studios cannot accept bounties",
      })
      return
    }

    toast({
      title: "Coming Soon",
      description: "Bounty acceptance feature is under development",
    })
  }

  const handleEditComplete = () => {
    setShowEditDialog(false)
    fetchBountyDetails()
  }

  if (isLoading || isRoleLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-200 rounded w-1/4"></div>
          <div className="h-8 bg-gray-200 rounded w-3/4"></div>
          <div className="space-y-3">
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    )
  }

  if (!bounty) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center">
          <h2 className="text-2xl font-bold">Bounty not found</h2>
          <Button
            variant="ghost"
            className="mt-4"
            onClick={() => router.push('/dashboard')}
          >
            ← Back to Dashboard
          </Button>
        </div>
      </div>
    )
  }

  const isOwner = user?.id === bounty.posterId

  return (
    <div className="container mx-auto p-6">
      <Button
        variant="ghost"
        className="mb-4"
        onClick={() => router.push('/dashboard')}
      >
        ← Back to Dashboard
      </Button>

      <Card className="w-full">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-2xl font-bold">{bounty.title}</CardTitle>
              <div className="mt-2 space-x-2">
                <Badge variant="outline">{bounty.category}</Badge>
                <Badge variant="outline">{bounty.difficulty}</Badge>
                <Badge variant="outline">{bounty.status}</Badge>
              </div>
            </div>
            <div className="space-x-2">
              {isOwner && userRole === 'STUDIO' && (
                <>
                  <Button
                    variant="outline"
                    onClick={() => setShowEditDialog(true)}
                  >
                    Edit
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive">Delete</Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This action cannot be undone. This will permanently delete the bounty.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleDelete}>
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </>
              )}
              {user && userRole === 'CREATOR' && !isOwner && bounty.status === 'OPEN' && (
                <ApplyToBountyDialog
                  bountyId={bounty.id}
                  bountyTitle={bounty.title}
                  onSuccess={fetchBountyDetails}
                />
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-2">Posted by</h3>
              <p>
                {bounty.poster?.studioProfile?.studioName || 
                 bounty.poster?.profile?.title || 
                 bounty.poster?.name || 
                 'Unknown'}
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-2">Description</h3>
              <p className="whitespace-pre-wrap">{bounty.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-lg font-semibold mb-2">Rewards</h3>
                <p>💰 ${bounty.monetaryReward}</p>
                <p>🪙 {bounty.coinReward} coins</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Deadline</h3>
                <p>{format(new Date(bounty.deadline), 'PPP')}</p>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-2">Requirements</h3>
              <div className="bg-muted p-4 rounded-lg">
                {bounty.requirements}
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-2">Deliverables</h3>
              <ul className="list-disc pl-6">
                {bounty.deliverables.map((item, index) => (
                  <li key={index}>{item}</li>
                ))}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {showEditDialog && (
        <EditBountyDialog
          bounty={bounty}
          open={showEditDialog}
          onOpenChange={setShowEditDialog}
          onComplete={handleEditComplete}
        />
      )}

      {isOwner && userRole === 'STUDIO' && (
        <>
          <div className="mt-6">
            <BountyApplicationsManager
              bountyId={bounty.id}
              onApplicationUpdate={fetchBountyDetails}
            />
          </div>
          <div className="mt-6">
            <MilestonesManager
              bountyId={bounty.id}
              isStudio={true}
              totalBudget={bounty.totalBudget}
              remainingBudget={bounty.remainingBudget}
            />
          </div>
        </>
      )}
      
      {!isOwner && userRole === 'CREATOR' && bounty.status === 'IN_PROGRESS' && (
        <div className="mt-6">
          <MilestonesManager
            bountyId={bounty.id}
            isStudio={false}
            totalBudget={bounty.totalBudget}
            remainingBudget={bounty.remainingBudget}
          />
        </div>
      )}
    </div>
  )
}