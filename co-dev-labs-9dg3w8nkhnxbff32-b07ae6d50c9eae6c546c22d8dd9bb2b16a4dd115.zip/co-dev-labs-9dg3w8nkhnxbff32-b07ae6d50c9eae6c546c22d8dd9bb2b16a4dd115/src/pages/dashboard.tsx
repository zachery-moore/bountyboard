import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { useEffect, useState } from "react";
import { CreateBountyDialog } from "@/components/CreateBountyDialog";
import { Badge } from "@/components/ui/badge";
import { DashboardNav } from "@/components/DashboardNav";
import { DailyChallenges } from "@/components/DailyChallenges";
import { StudioFinancialDashboard } from "@/components/StudioFinancialDashboard";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AchievementsDisplay } from "@/components/AchievementsDisplay";

interface UserProfile {
  id: string;
  role: 'CREATOR' | 'STUDIO';
  name: string;
  xp: number;
  level: number;
  guildCoins: number;
  theme: string;
  profileData: any;
  achievements: Array<{
    achievement: {
      title: string;
      description: string;
      icon: string;
    };
  }>;
}

interface Bounty {
  id: string;
  title: string;
  description: string;
  difficulty: string;
  status: string;
  category: string;
  monetaryReward: number;
  xpReward: number;
  coinReward: number;
  deadline: string;
  createdAt: string;
}

interface FinancialStats {
  totalSpent: number;
  monthlyBudget: number;
  activePayments: number;
  completedPayments: number;
  recentTransactions: Array<{
    id: string;
    amount: number;
    status: string;
    bountyTitle: string;
    creatorName: string;
    date: string;
  }>;
  monthlySpending: Array<{
    month: string;
    amount: number;
  }>;
}

interface StudioStatistics {
  totalBounties: number;
  activeBounties: number;
  totalApplications: number;
  activeApplications: number;
  completedBounties: number;
  averageApplicationsPerBounty: number;
  recentApplications: Array<{
    id: string;
    status: string;
    createdAt: string;
    bounty: {
      title: string;
    };
    creator: {
      name: string;
    };
  }>;
}

export default function Dashboard() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [bounties, setBounties] = useState<Bounty[]>([]);
  const [studioStats, setStudioStats] = useState<StudioStatistics | null>(null);
  const [financialStats, setFinancialStats] = useState<FinancialStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    
    const fetchData = async () => {
      if (!user) {
        if (mounted) {
          setLoading(false);
        }
        return;
      }

      try {
        // Fetch profile
        const profileResponse = await fetch('/api/profile');
        if (!profileResponse.ok) {
          throw new Error('Failed to fetch profile');
        }
        const profileData = await profileResponse.json();
        
        if (!mounted) return;
        setProfile(profileData);

        // Fetch bounties
        const bountiesResponse = await fetch('/api/bounties');
        if (bountiesResponse.ok) {
          const bountiesData = await bountiesResponse.json();
          if (mounted) {
            setBounties(bountiesData);
          }
        }

        // If studio role, fetch additional data
        if (profileData.role === 'STUDIO') {
          try {
            const [statsResponse, financialResponse] = await Promise.all([
              fetch('/api/studio/statistics'),
              fetch('/api/studio/financial-stats')
            ]);

            if (mounted) {
              if (statsResponse.ok) {
                const statsData = await statsResponse.json();
                setStudioStats(statsData);
              }

              if (financialResponse.ok) {
                const financialData = await financialResponse.json();
                setFinancialStats(financialData);
              }
            }
          } catch (err) {
            console.error('Error fetching studio data:', err);
            if (mounted) {
              setError('Failed to load some studio data. Please refresh the page.');
            }
          }
        }
      } catch (err) {
        console.error('Error fetching data:', err);
        if (mounted) {
          setError('Failed to load profile data. Please refresh the page.');
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    fetchData();

    return () => {
      mounted = false;
    };
  }, [user]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="text-lg">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center space-y-4">
          <p className="text-lg text-red-500">{error}</p>
          <Button onClick={() => window.location.reload()}>Retry</Button>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center space-y-4">
          <p className="text-lg">Profile not found. Please try logging in again.</p>
          <Button onClick={() => window.location.href = '/login'}>Go to Login</Button>
        </div>
      </div>
    );
  }

  const getDifficultyColor = (difficulty: string) => {
    const colors: Record<string, string> = {
      EASY: 'bg-green-500',
      MEDIUM: 'bg-yellow-500',
      HARD: 'bg-orange-500',
      LEGENDARY: 'bg-red-500'
    };
    return colors[difficulty] || 'bg-gray-500';
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      OPEN: 'bg-green-500',
      IN_PROGRESS: 'bg-blue-500',
      UNDER_REVIEW: 'bg-yellow-500',
      COMPLETED: 'bg-purple-500',
      CANCELLED: 'bg-gray-500'
    };
    return colors[status] || 'bg-gray-500';
  };

  const calculateLevelProgress = () => {
    const currentXP = profile?.xp || 0;
    const currentLevel = profile?.level || 1;
    const xpForNextLevel = currentLevel * 1000;
    const xpInCurrentLevel = currentXP % 1000;
    return (xpInCurrentLevel / xpForNextLevel) * 100;
  };

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />
      <main className="container mx-auto p-8 space-y-6">
        {/* Welcome Section */}
        <Card className="border-2 border-primary/20">
          <CardHeader>
            <CardTitle className="text-3xl font-bold">
              Welcome back, {profile?.name || user?.email}!
            </CardTitle>
            <CardDescription>
              {profile?.role || 'User'} • Level {profile?.level || 1}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Level Progress</span>
                  <span>{profile?.xp || 0} / {((profile?.level || 1) * 1000)} XP</span>
                </div>
                <Progress value={calculateLevelProgress()} className="h-2" />
              </div>
              <div className="flex items-center gap-4">
                {profile?.role === 'STUDIO' && <CreateBountyDialog />}
                <Button
                  onClick={() => window.location.href = '/bounties'}
                  variant="secondary"
                >
                  View Bounty Board
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {profile?.role === 'STUDIO' ? (
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="applications">Applications</TabsTrigger>
              <TabsTrigger value="metrics">Metrics</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              {/* Studio Statistics Overview */}
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader>
                    <CardTitle>Active Bounties</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold">{studioStats?.activeBounties || 0}</p>
                    <p className="text-sm text-muted-foreground">Out of {studioStats?.totalBounties || 0} total bounties</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Active Applications</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold">{studioStats?.activeApplications || 0}</p>
                    <p className="text-sm text-muted-foreground">Pending review or in progress</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Completed Bounties</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold">{studioStats?.completedBounties || 0}</p>
                    <p className="text-sm text-muted-foreground">Successfully delivered</p>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Applications */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Applications</CardTitle>
                  <CardDescription>Latest creator submissions</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[300px] pr-4">
                    {studioStats?.recentApplications && studioStats.recentApplications.length > 0 ? (
                      <div className="space-y-4">
                        {studioStats.recentApplications.map((application) => (
                          <div
                            key={application.id}
                            className="flex items-center justify-between p-4 border rounded-lg"
                          >
                            <div>
                              <p className="font-medium">{application.bounty.title}</p>
                              <p className="text-sm text-muted-foreground">
                                by {application.creator.name}
                              </p>
                            </div>
                            <Badge className={getStatusColor(application.status)}>
                              {application.status}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        <p>No recent applications</p>
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="applications" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Application Statistics</CardTitle>
                  <CardDescription>Overview of creator engagement</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <p className="text-sm text-muted-foreground">Total Applications</p>
                        <p className="text-3xl font-bold">{studioStats?.totalApplications || 0}</p>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm text-muted-foreground">Avg. Applications per Bounty</p>
                        <p className="text-3xl font-bold">{studioStats?.averageApplicationsPerBounty || 0}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Active Bounties List */}
              <Card>
                <CardHeader>
                  <CardTitle>Active Bounties</CardTitle>
                  <CardDescription>Currently open for applications</CardDescription>
                </CardHeader>
                <CardContent>
                  {bounties.length > 0 ? (
                    <div className="space-y-4">
                      {bounties.slice(0, 5).map((bounty) => (
                        <div
                          key={bounty.id}
                          className="flex items-center justify-between p-4 border rounded-lg cursor-pointer hover:bg-accent"
                          onClick={() => window.location.href = `/bounties/${bounty.id}`}
                        >
                          <div>
                            <p className="font-medium">{bounty.title}</p>
                            <p className="text-sm text-muted-foreground">{bounty.category}</p>
                          </div>
                          <Badge className={getStatusColor(bounty.status)}>{bounty.status}</Badge>
                        </div>
                      ))}
                      <Button
                        variant="outline"
                        className="w-full"
                        onClick={() => window.location.href = '/bounties'}
                      >
                        View All Bounties
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <p>No active bounties</p>
                      <CreateBountyDialog className="mt-4" />
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="metrics" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Bounty Performance</CardTitle>
                  <CardDescription>Track your bounty success metrics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-8">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Completion Rate</span>
                        <span>
                          {studioStats?.totalBounties 
                            ? Math.round((studioStats.completedBounties / studioStats.totalBounties) * 100)
                            : 0}%
                        </span>
                      </div>
                      <Progress 
                        value={studioStats?.totalBounties 
                          ? (studioStats.completedBounties / studioStats.totalBounties) * 100
                          : 0} 
                        className="h-2"
                      />
                    </div>
                    
                    <div className="grid gap-4 md:grid-cols-2">
                      <Card>
                        <CardHeader>
                          <CardTitle>Total Bounties</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-3xl font-bold">{studioStats?.totalBounties || 0}</p>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader>
                          <CardTitle>Success Rate</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-3xl font-bold">
                            {studioStats?.totalBounties 
                              ? Math.round((studioStats.completedBounties / studioStats.totalBounties) * 100)
                              : 0}%
                          </p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Financial Dashboard */}
              {financialStats && <StudioFinancialDashboard stats={financialStats} />}
            </TabsContent>
          </Tabs>
        ) : (
          <>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle>Experience Points</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">{profile?.xp || 0} XP</p>
                  <p className="text-sm text-muted-foreground">Next level: {((profile?.level || 1) * 1000)} XP</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Guild Coins</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">{profile?.guildCoins || 0} 🪙</p>
                  <p className="text-sm text-muted-foreground">Earn more by completing bounties</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Achievements</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">{profile?.achievements?.length || 0}/10</p>
                  <p className="text-sm text-muted-foreground">Complete bounties to earn achievements</p>
                </CardContent>
              </Card>
            </div>

            <AchievementsDisplay />
            
            <DailyChallenges />
            
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Available Bounties</CardTitle>
                  <CardDescription>Latest opportunities</CardDescription>
                </CardHeader>
                <CardContent>
                  {bounties.length > 0 ? (
                    <div className="space-y-4">
                      {bounties.slice(0, 3).map((bounty) => (
                        <div
                          key={bounty.id}
                          className="flex items-center justify-between p-4 border rounded-lg cursor-pointer hover:bg-accent"
                          onClick={() => window.location.href = `/bounties/${bounty.id}`}
                        >
                          <div>
                            <p className="font-medium">{bounty.title}</p>
                            <p className="text-sm text-muted-foreground">{bounty.category}</p>
                          </div>
                          <Badge className={getStatusColor(bounty.status)}>{bounty.status}</Badge>
                        </div>
                      ))}
                      <Button
                        variant="outline"
                        className="w-full"
                        onClick={() => window.location.href = '/bounties'}
                      >
                        View All Bounties
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <p>No active bounties</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Your latest actions and updates</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8 text-muted-foreground">
                    <p>No recent activity to display.</p>
                    <p className="mt-2">Start browsing available bounties to begin your journey!</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </main>
    </div>
  );
}