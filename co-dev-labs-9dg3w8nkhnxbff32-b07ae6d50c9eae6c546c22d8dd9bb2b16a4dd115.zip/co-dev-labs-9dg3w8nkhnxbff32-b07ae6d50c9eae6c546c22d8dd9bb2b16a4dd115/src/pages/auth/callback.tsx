import { useEffect } from 'react'
import { useRouter } from 'next/router'
import { createClient } from '@/util/supabase/component'

export default function AuthCallback() {
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const handleCallback = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession()
        
        if (error) throw error
        
        if (session) {
          // Get the stored redirect URL or default to dashboard
          const redirectTo = sessionStorage.getItem('redirectAfterLogin') || '/dashboard'
          sessionStorage.removeItem('redirectAfterLogin')
          
          // Use replace to prevent back button from returning to callback page
          await router.replace(redirectTo)
        }
      } catch (error) {
        console.error('Auth callback error:', error)
        // Redirect to login page if there's an error
        await router.replace('/login')
      }
    }

    handleCallback()
  }, [router])

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gray-900"></div>
    </div>
  )
}