import { useFormik } from 'formik';
import React, { useContext, useState } from 'react';
import * as Yup from 'yup';
import { useRouter } from 'next/navigation';
import { AuthContext } from '@/contexts/AuthContext';
import { FaEye, FaEyeSlash } from 'react-icons/fa';
import GoogleButton from '@/components/GoogleButton';
import Logo from '@/components/Logo';
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

const VerificationInstructions = ({ email }: { email: string }) => {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-center">Check Your Email ✉️</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-6">
        <div className="text-center space-y-4">
          <p className="text-muted-foreground">
            We've sent a verification link to:
          </p>
          <p className="font-medium">{email}</p>
          <p className="text-muted-foreground text-sm">
            Please click the link in the email to verify your account. 
            If you don't see it, check your spam folder.
          </p>
        </div>
        <div className="flex flex-col gap-4">
          <Button
            variant="outline"
            onClick={() => window.location.href = '/login'}
          >
            Go to Login
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

const SignUpForm = ({
  formik,
  isLoading,
  initializing,
  cooldownTime,
  showPw,
  setShowPw,
  router
}: any) => {
  const handleKeyPress = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      formik.handleSubmit();
    }
  };

  return (
    <Card className="w-full" onKeyDown={handleKeyPress}>
      <CardHeader>
        <CardTitle className="text-center">Begin Your Quest</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={formik.handleSubmit}>
          <div className="flex flex-col gap-6">
            <div className="flex flex-col gap-4">
              <GoogleButton />
              <Button
                onClick={(e) => {
                  e.preventDefault();
                  router.push('/magic-link-login');
                }}
                variant="outline"
              >
                Continue with Magic Link
              </Button>
            </div>

            <div className="flex items-center w-full">
              <Separator className="flex-1" />
              <span className="mx-4 text-muted-foreground text-sm font-semibold whitespace-nowrap">or</span>
              <Separator className="flex-1" />
            </div>

            <div className="flex flex-col gap-6">
              <p className="text-center text-sm text-muted-foreground">Choose your path</p>
              
              <div className="flex flex-col gap-4">
                <div className="flex flex-col gap-2">
                  <Label>I am a...</Label>
                  <RadioGroup
                    onValueChange={(value) => formik.setFieldValue('userType', value)}
                    className="flex gap-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="CREATOR" id="creator" />
                      <Label htmlFor="creator" className="cursor-pointer">Creator</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="STUDIO" id="studio" />
                      <Label htmlFor="studio" className="cursor-pointer">Game Studio</Label>
                    </div>
                  </RadioGroup>
                  {formik.touched.userType && formik.errors.userType && (
                    <p className="text-destructive text-xs">{formik.errors.userType}</p>
                  )}
                </div>

                <div className="flex flex-col gap-2">
                  <Label htmlFor="displayName">
                    {formik.values.userType === 'STUDIO' ? 'Studio Name' : 'Display Name'}
                  </Label>
                  <Input
                    id="displayName"
                    name="displayName"
                    type="text"
                    placeholder={formik.values.userType === 'STUDIO' ? 'Enter your studio name' : 'Choose your display name'}
                    value={formik.values.displayName}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.touched.displayName && formik.errors.displayName && (
                    <p className="text-destructive text-xs">{formik.errors.displayName}</p>
                  )}
                </div>

                <div className="flex flex-col gap-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="Enter your email"
                    value={formik.values.email}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.touched.email && formik.errors.email && (
                    <p className="text-destructive text-xs">{formik.errors.email}</p>
                  )}
                </div>

                <div className="flex flex-col gap-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      name="password"
                      type={showPw ? 'text' : 'password'}
                      placeholder="Enter your password"
                      value={formik.values.password}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      onClick={() => setShowPw(!showPw)}
                    >
                      {showPw
                        ? <FaEye className="text-muted-foreground" />
                        : <FaEyeSlash className="text-muted-foreground" />
                      }
                    </Button>
                  </div>
                  {formik.touched.password && formik.errors.password && (
                    <p className="text-destructive text-xs">{formik.errors.password}</p>
                  )}
                </div>

                <div className="flex justify-end mt-2 text-sm">
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <span>Already have an account?</span>
                    <Button
                      type="button"
                      variant="link"
                      className="p-0"
                      onClick={() => router.push('/login')}
                    >
                      Log in
                    </Button>
                  </div>
                </div>
              </div>
            </div>
            <Button
              type="submit"
              className="w-full"
              disabled={isLoading || initializing || !formik.isValid || cooldownTime > 0}
            >
              {isLoading 
                ? "Creating Account..." 
                : cooldownTime > 0 
                  ? `Please wait ${cooldownTime}s...` 
                  : "Begin Your Journey"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

const SignUpPage = () => {
  const router = useRouter();
  const { initializing, signUp } = useContext(AuthContext);
  const [showPw, setShowPw] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [cooldownTime, setCooldownTime] = useState(0);
  const [registrationSuccess, setRegistrationSuccess] = useState(false);
  const [registeredEmail, setRegisteredEmail] = useState('');
  const { toast } = useToast();

  React.useEffect(() => {
    if (cooldownTime > 0) {
      const timer = setTimeout(() => {
        setCooldownTime(time => Math.max(0, time - 1));
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [cooldownTime]);

  const handleSubmit = async (values: any) => {
    if (cooldownTime > 0) {
      toast({
        variant: "destructive",
        title: "Please wait",
        description: `You can try again in ${cooldownTime} seconds.`,
      });
      return;
    }

    setIsLoading(true);
    try {
      const { email, password, userType, displayName } = values;
      
      await signUp(email, password, userType, displayName);
      
      setRegisteredEmail(email);
      setRegistrationSuccess(true);
      
      toast({
        title: "Almost there! 📧",
        description: "Please check your email to verify your account. You'll be able to log in after verification.",
      });
    } catch (error: any) {
      console.error(error);
      
      // Handle rate limiting error
      if (error.message?.includes('security purposes') || error.status === 429) {
        setCooldownTime(60); // Set cooldown timer to 60 seconds
        toast({
          variant: "destructive",
          title: "Too many attempts",
          description: "Please wait 60 seconds before trying again.",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Sign up failed",
          description: error.message || "Please try again.",
        });
      }
    } finally {
      setIsLoading(false);
    }
  }

  const validationSchema = Yup.object().shape({
    email: Yup.string().required("Email is required").email("Email is invalid"),
    password: Yup.string()
      .required("Password is required")
      .min(4, "Must be at least 4 characters")
      .max(40, "Must not exceed 40 characters"),
    displayName: Yup.string()
      .required("Display name is required")
      .min(2, "Must be at least 2 characters")
      .max(30, "Must not exceed 30 characters"),
    userType: Yup.string()
      .required("Please select your role")
      .oneOf(['CREATOR', 'STUDIO'], "Invalid role selected"),
  });

  const formik = useFormik({
    initialValues: {
      email: '',
      password: '',
      displayName: '',
      userType: '',
    },
    validationSchema,
    onSubmit: handleSubmit,
  });

  const handleKeyPress = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      formik.handleSubmit();
    }
  };

  return (
    <div className="flex min-h-screen bg-background justify-center items-center py-8">
      <div className="flex flex-col gap-5 h-auto w-full max-w-[440px] px-4">
        <div className="w-full flex justify-center cursor-pointer" onClick={() => router.push("/")}>
          <Logo />
        </div>

        {registrationSuccess ? (
          <VerificationInstructions email={registeredEmail} />
        ) : (
          <SignUpForm
            formik={formik}
            isLoading={isLoading}
            initializing={initializing}
            cooldownTime={cooldownTime}
            showPw={showPw}
            setShowPw={setShowPw}
            router={router}
          />
        )}
      </div>
    </div>
  );
};

export default SignUpPage;