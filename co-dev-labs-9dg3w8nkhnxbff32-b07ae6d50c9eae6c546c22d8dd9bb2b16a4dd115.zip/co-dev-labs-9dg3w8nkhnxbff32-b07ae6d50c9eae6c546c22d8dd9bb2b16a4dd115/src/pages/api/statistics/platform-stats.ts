import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '@/lib/prisma';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const [
      activeBounties,
      totalUsers,
      totalStudios,
      totalPayments
    ] = await Promise.all([
      // Get count of active bounties
      prisma.bounty.count({
        where: {
          status: { in: ['OPEN', 'IN_PROGRESS'] },
        },
      }),
      // Get count of all users (creators)
      prisma.user.count({
        where: {
          role: 'CREATOR',
        },
      }),
      // Get count of game studios
      prisma.user.count({
        where: {
          role: 'STUDIO',
        },
      }),
      // Get sum of all completed payments
      prisma.payment.aggregate({
        _sum: {
          amount: true,
        },
        where: {
          status: 'COMPLETED',
        },
      }),
    ]);

    const stats = {
      activeBounties,
      totalUsers,
      totalStudios,
      totalPayments: totalPayments._sum.amount || 0,
    };

    return res.status(200).json(stats);
  } catch (error) {
    console.error('Error fetching platform statistics:', error);
    return res.status(500).json({ message: 'Error fetching platform statistics' });
  }
}