import { NextApiRequest, NextApiResponse } from 'next';
import { createClient } from '@/util/supabase/api';
import prisma from '@/lib/prisma';
import { SkillCategory } from '@prisma/client';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'PUT') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const supabase = createClient(req, res);
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    const {
      name,
      bio,
      avatarUrl,
      // Creator-specific fields
      title,
      specialties,
      availability,
      portfolioItems,
      // Studio-specific fields
      studioName,
      website,
      description,
    } = req.body;

    const existingUser = await prisma.user.findUnique({
      where: { id: user.id },
      include: {
        profile: true,
        studioProfile: true,
      },
    });

    if (!existingUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Update base user information
    const updatedUser = await prisma.user.update({
      where: { id: user.id },
      data: {
        name: name || undefined,
        bio: bio || undefined,
        avatarUrl: avatarUrl || undefined,
      },
      include: {
        profile: true,
        studioProfile: true,
      },
    });

    // Update role-specific information
    if (existingUser.role === 'CREATOR' && existingUser.profile) {
      await prisma.creatorProfile.update({
        where: { userId: user.id },
        data: {
          title: title || undefined,
          specialties: specialties ? specialties as SkillCategory[] : undefined,
          availability: availability !== undefined ? availability : undefined,
          portfolioItems: portfolioItems || undefined,
        },
      });
    } else if (existingUser.role === 'STUDIO' && existingUser.studioProfile) {
      await prisma.studioProfile.update({
        where: { userId: user.id },
        data: {
          studioName: studioName || undefined,
          website: website || undefined,
          description: description || undefined,
        },
      });
    }

    return res.status(200).json({ message: 'Profile updated successfully' });
  } catch (error) {
    console.error('Profile update error:', error);
    return res.status(500).json({ 
      message: 'Failed to update profile',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}