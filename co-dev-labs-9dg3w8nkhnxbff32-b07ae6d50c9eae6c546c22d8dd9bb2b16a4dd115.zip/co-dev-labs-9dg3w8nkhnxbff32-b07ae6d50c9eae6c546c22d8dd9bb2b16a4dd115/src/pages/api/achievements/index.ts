import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '@/lib/prisma';
import { createClient } from '@/util/supabase/api';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const supabase = createClient(req, res);
  const { data: { user }, error: authError } = await supabase.auth.getUser();

  if (authError || !user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (req.method === 'GET') {
    try {
      // Get user's achievements
      const userAchievements = await prisma.userAchievement.findMany({
        where: {
          userId: user.id,
        },
        include: {
          achievement: true,
        },
      });

      // Get all available achievements
      const allAchievements = await prisma.achievement.findMany({
        where: {
          OR: [
            { isSecret: false },
            {
              id: {
                in: userAchievements.map(ua => ua.achievementId)
              }
            }
          ]
        },
      });

      // Format the response
      const formattedAchievements = allAchievements.map(achievement => ({
        ...achievement,
        unlocked: userAchievements.some(ua => ua.achievementId === achievement.id),
        unlockedAt: userAchievements.find(ua => ua.achievementId === achievement.id)?.unlockedAt,
      }));

      return res.status(200).json(formattedAchievements);
    } catch (error) {
      console.error('Error fetching achievements:', error);
      return res.status(500).json({ error: 'Internal server error' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}