import { NextApiRequest, NextApiResponse } from 'next';
import { createClient } from '@/util/supabase/api';
import prisma from '@/lib/prisma';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // Allow GET method for easier testing
  if (req.method !== 'GET' && req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const supabase = createClient(req, res);
    
    // For the specific email case
    const targetEmail = 'me@zacherymoore.com';
    
    // First, find the user in Supabase
    const { data: { users }, error: supabaseError } = await supabase.auth.admin.listUsers();
    if (supabaseError) {
      throw supabaseError;
    }

    const targetUser = users.find(u => u.email === targetEmail);
    if (!targetUser) {
      return res.status(404).json({ message: 'User not found in Supabase' });
    }

    // Update Supabase user metadata
    const { error: updateError } = await supabase.auth.admin.updateUserById(
      targetUser.id,
      { user_metadata: { userType: 'STUDIO' } }
    );

    if (updateError) {
      throw updateError;
    }

    // Find the user in our database
    const existingUser = await prisma.user.findUnique({
      where: {
        id: targetUser.id,
      },
      include: {
        profile: true,
        studioProfile: true,
      },
    });

    if (!existingUser) {
      return res.status(404).json({ message: 'User not found in database' });
    }

    // Delete creator profile if exists
    if (existingUser.profile) {
      await prisma.creatorProfile.delete({
        where: {
          userId: targetUser.id,
        },
      });
    }

    // Update user role and create studio profile if it doesn't exist
    const updatedUser = await prisma.user.update({
      where: {
        id: targetUser.id,
      },
      data: {
        role: 'STUDIO',
        ...(existingUser.studioProfile ? {} : {
          studioProfile: {
            create: {
              studioName: existingUser.name || 'New Studio',
              verified: false,
              totalSpent: 0,
              questsPosted: 0
            }
          }
        })
      },
      include: {
        studioProfile: true
      }
    });

    // If this was a GET request, redirect to dashboard
    if (req.method === 'GET') {
      res.setHeader('Content-Type', 'text/html');
      return res.send(`
        <html>
          <body>
            <h1>Successfully converted user to studio!</h1>
            <p>User ${targetEmail} has been converted to a studio account.</p>
            <script>
              setTimeout(() => {
                window.location.href = '/dashboard';
              }, 3000);
            </script>
          </body>
        </html>
      `);
    }

    return res.status(200).json({
      message: 'Successfully converted user to studio',
      user: updatedUser
    });
  } catch (error) {
    console.error('Conversion error:', error);
    return res.status(500).json({ 
      message: 'Internal server error',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}