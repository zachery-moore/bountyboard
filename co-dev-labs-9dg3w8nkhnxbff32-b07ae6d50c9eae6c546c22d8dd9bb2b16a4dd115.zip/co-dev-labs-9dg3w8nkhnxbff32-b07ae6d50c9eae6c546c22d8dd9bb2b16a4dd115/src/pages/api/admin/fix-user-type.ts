import { NextApiRequest, NextApiResponse } from 'next';
import { createClient } from '@/util/supabase/api';
import prisma from '@/lib/prisma';
import { UserType } from '@prisma/client';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const supabase = createClient(req, res);
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    // Get the current user's metadata
    const userMetadata = user.user_metadata;
    console.log('Current user metadata:', userMetadata);

    // Find the user in the database
    const dbUser = await prisma.user.findUnique({
      where: { id: user.id },
      include: {
        profile: true,
        studioProfile: true,
      },
    });

    if (!dbUser) {
      return res.status(404).json({ message: 'User not found in database' });
    }

    // Get the intended role from metadata or current role
    const intendedRole = (userMetadata?.role || dbUser.role).toUpperCase();
    
    if (!['CREATOR', 'STUDIO'].includes(intendedRole)) {
      return res.status(400).json({ message: 'Invalid role type' });
    }

    // If the role is already correct, no need to update
    if (dbUser.role === intendedRole) {
      return res.status(200).json({ 
        message: 'User role is already correct',
        role: intendedRole
      });
    }

    // Update the user's role and create appropriate profile
    if (intendedRole === 'STUDIO') {
      // Delete creator profile if it exists
      if (dbUser.profile) {
        await prisma.creatorProfile.delete({
          where: { userId: user.id }
        });
      }

      // Create studio profile if it doesn't exist
      if (!dbUser.studioProfile) {
        await prisma.studioProfile.create({
          data: {
            userId: user.id,
            studioName: dbUser.name,
            verified: false,
            totalSpent: 0,
            bountiesPosted: 0
          }
        });
      }
    } else {
      // Delete studio profile if it exists
      if (dbUser.studioProfile) {
        await prisma.studioProfile.delete({
          where: { userId: user.id }
        });
      }

      // Create creator profile if it doesn't exist
      if (!dbUser.profile) {
        await prisma.creatorProfile.create({
          data: {
            userId: user.id,
            totalEarned: 0,
            questsCompleted: 0,
            availability: true,
            averageRating: 0,
            successRate: 0,
            specialties: [],
            portfolioItems: []
          }
        });
      }
    }

    // Update user role
    await prisma.user.update({
      where: { id: user.id },
      data: { role: intendedRole as UserType }
    });

    // Update Supabase metadata to ensure it's in sync
    await supabase.auth.updateUser({
      data: { role: intendedRole }
    });

    return res.status(200).json({
      message: 'User role and profile updated successfully',
      newRole: intendedRole
    });

  } catch (error) {
    console.error('Error fixing user type:', error);
    return res.status(500).json({
      message: 'Internal server error',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}