import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '@/lib/prisma';
import { createClient } from '@/util/supabase/api';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const supabase = createClient(req, res);
    const { data: { user }, error: authError } = await supabase.auth.getUser();

    if (authError || !user) {
      console.error('Auth error:', authError);
      return res.status(401).json({ message: 'Unauthorized' });
    }

    // Get user profile to verify studio role
    const profile = await prisma.user.findUnique({
      where: { id: user.id },
      include: {
        studioProfile: true
      }
    });

    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    if (profile.role !== 'STUDIO') {
      return res.status(403).json({ message: 'Forbidden - Studio access only' });
    }

    // Get bounty statistics
    const [
      totalBounties,
      activeBounties,
      totalApplications,
      activeApplications,
      completedBounties,
    ] = await Promise.all([
      // Total bounties
      prisma.bounty.count({
        where: { posterId: user.id },
      }),
      // Active bounties
      prisma.bounty.count({
        where: {
          posterId: user.id,
          status: { in: ['OPEN', 'IN_PROGRESS'] },
        },
      }),
      // Total applications
      prisma.bountyApplication.count({
        where: {
          bounty: { posterId: user.id },
        },
      }),
      // Active applications
      prisma.bountyApplication.count({
        where: {
          bounty: { posterId: user.id },
          status: { in: ['PENDING', 'ACCEPTED'] },
        },
      }),
      // Completed bounties
      prisma.bounty.count({
        where: {
          posterId: user.id,
          status: 'COMPLETED',
        },
      }),
    ]);

    // Get recent applications with proper error handling
    const recentApplications = await prisma.bountyApplication.findMany({
      where: {
        bounty: { posterId: user.id },
      },
      include: {
        bounty: {
          select: {
            title: true,
          },
        },
        applicant: {
          select: {
            name: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
      take: 5,
    });

    // Transform the applications data with null checks
    const transformedApplications = recentApplications.map(app => ({
      id: app.id,
      status: app.status,
      createdAt: app.createdAt,
      bounty: {
        title: app.bounty?.title ?? 'Untitled Bounty',
      },
      creator: {
        name: app.applicant?.name ?? 'Anonymous',
      },
    }));

    return res.status(200).json({
      totalBounties,
      activeBounties,
      totalApplications,
      activeApplications,
      completedBounties,
      averageApplicationsPerBounty: totalBounties > 0 ? Math.round((totalApplications / totalBounties) * 10) / 10 : 0,
      recentApplications: transformedApplications,
    });
  } catch (error) {
    console.error('Error in statistics endpoint:', error);
    return res.status(500).json({ 
      message: 'Internal server error',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}