import { NextApiRequest, NextApiResponse } from 'next';
import { createClient } from '@/util/supabase/api';
import prisma from '@/lib/prisma';
import stripe from '@/lib/stripe';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const supabase = createClient(req, res);
    const { data: { user }, error: authError } = await supabase.auth.getUser();

    if (authError || !user) {
      console.error('Auth error:', authError);
      return res.status(401).json({ message: 'Unauthorized' });
    }

    console.log('Checking for user:', user.id);

    try {
      const studioProfile = await prisma.studioProfile.findUnique({
        where: { userId: user.id },
        select: {
          bankingStatus: true,
          bankingSetupCompleted: true,
          stripeAccountId: true
        }
      });

      if (!studioProfile?.stripeAccountId) {
        return res.json({
          hasPaymentMethod: false,
          bankingStatus: 'NOT_FOUND',
          paymentMethodStatus: 'NOT_SETUP'
        });
      }

      // Get the account details from Stripe
      const stripeAccount = await stripe.accounts.retrieve(studioProfile.stripeAccountId);
      
      // Check if the account has external accounts (bank accounts) set up
      const hasValidBankAccount = stripeAccount.external_accounts?.data?.length > 0;
      
      // Check if the account is fully set up and enabled
      const isAccountEnabled = stripeAccount.charges_enabled && stripeAccount.payouts_enabled;

      // Consider setup complete if account is enabled and has a valid bank account
      const hasValidSetup = hasValidBankAccount && isAccountEnabled;

      // Update the banking status in our database if needed
      if (hasValidSetup && studioProfile.bankingStatus !== 'active') {
        await prisma.studioProfile.update({
          where: { userId: user.id },
          data: {
            bankingStatus: 'active',
            bankingSetupCompleted: new Date()
          }
        });
      }

      return res.json({
        hasPaymentMethod: hasValidSetup,
        bankingStatus: hasValidSetup ? 'active' : studioProfile.bankingStatus || 'NOT_FOUND',
        paymentMethodStatus: hasValidSetup ? 'ACTIVE' : 'NOT_SETUP',
        stripeAccountStatus: {
          hasValidBankAccount,
          isAccountEnabled
        }
      });
    } catch (dbError) {
      console.error('Database error:', dbError);
      throw dbError;
    }
  } catch (err) {
    console.error('Detailed error:', err);
    return res.status(500).json({ 
      message: 'Error checking payment method',
      details: err instanceof Error ? err.message : 'Unknown error'
    });
  }
}