import { NextApiRequest, NextApiResponse } from 'next';
import { createClient } from '@/util/supabase/api';
import prisma from '@/lib/prisma';
import Stripe from 'stripe';
import stripe from '@/lib/stripe';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const supabase = createClient(req, res);
    
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      console.error('Auth error:', authError);
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const userProfile = await prisma.user.findUnique({
      where: { id: user.id },
      include: {
        studioProfile: true
      }
    });

    if (!userProfile) {
      return res.status(404).json({ error: 'Profile not found' });
    }

    if (userProfile.role !== 'STUDIO') {
      return res.status(403).json({ error: 'Only studio accounts can access banking information' });
    }

    if (!userProfile.studioProfile?.stripeAccountId) {
      return res.json({ 
        isSetup: false,
        status: 'not_started',
        lastFourBank: null
      });
    }

    try {
      const account = await stripe.accounts.retrieve(userProfile.studioProfile.stripeAccountId);
      
      const isSetup = account.details_submitted && account.payouts_enabled;
      
      let lastFourBank = null;
      if (account.external_accounts?.data && account.external_accounts.data.length > 0) {
        const bankAccount = account.external_accounts.data[0] as Stripe.BankAccount;
        lastFourBank = bankAccount.last4;
      }

      return res.json({
        isSetup,
        lastFourBank,
        status: account.payouts_enabled ? 'active' : account.details_submitted ? 'pending' : 'incomplete',
      });
    } catch (stripeError: any) {
      console.error('Stripe account retrieval error:', stripeError);
      return res.status(500).json({ 
        error: 'Failed to fetch Stripe account details',
        details: stripeError.message
      });
    }
  } catch (error: any) {
    console.error('Banking status error:', error);
    return res.status(500).json({ 
      error: 'Failed to fetch banking status',
      details: error.message
    });
  }
}