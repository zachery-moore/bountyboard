import { NextApiRequest, NextApiResponse } from 'next'
import { createClient } from '@/util/supabase/api'
import prisma from '@/lib/prisma'

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' })
  }

  try {
    const supabase = createClient(req, res)
    const { data: { user }, error: userError } = await supabase.auth.getUser()

    if (userError || !user) {
      return res.status(401).json({ message: 'Unauthorized' })
    }

    // Get user profile to verify studio role
    const profile = await prisma.user.findUnique({
      where: { id: user.id },
      include: {
        studioProfile: true
      }
    })

    if (!profile || profile.role !== 'STUDIO') {
      return res.status(403).json({ message: 'Forbidden - Studio access only' })
    }

    // Get current date and first day of current month
    const now = new Date()
    const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)

    // Get all payments for the studio
    const payments = await prisma.payment.findMany({
      where: {
        bounty: {
          posterId: user.id,
        },
      },
      include: {
        bounty: {
          select: {
            title: true,
          },
        },
        milestone: {
          select: {
            title: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    })

    // Calculate monthly spending for the last 6 months
    const monthlySpending = []
    for (let i = 5; i >= 0; i--) {
      const month = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const monthEnd = new Date(now.getFullYear(), now.getMonth() - i + 1, 0)
      
      const monthlyAmount = payments
        .filter(p => {
          const paymentDate = new Date(p.createdAt)
          return paymentDate >= month && paymentDate <= monthEnd
        })
        .reduce((sum, p) => sum + (p.amount || 0), 0)

      monthlySpending.push({
        month: month.toLocaleString('default', { month: 'short' }),
        amount: monthlyAmount,
      })
    }

    // Calculate current month statistics
    const currentMonthPayments = payments.filter(p => 
      new Date(p.createdAt) >= firstDayOfMonth
    )

    const totalSpent = currentMonthPayments.reduce((sum, p) => sum + (p.amount || 0), 0)
    const activePayments = currentMonthPayments.filter(p => 
      p.status === 'PENDING' || p.status === 'PROCESSING'
    ).length
    const completedPayments = currentMonthPayments.filter(p => 
      p.status === 'COMPLETED'
    ).length

    // Format recent transactions
    const recentTransactions = payments.slice(0, 10).map(p => ({
      id: p.id,
      amount: p.amount || 0,
      status: p.status,
      bountyTitle: p.bounty?.title || 'Unknown Bounty',
      milestoneTitle: p.milestone?.title || null,
      date: p.createdAt,
    }))

    // For demo purposes, set a fixed monthly budget
    const monthlyBudget = 10000

    const stats = {
      totalSpent,
      monthlyBudget,
      activePayments,
      completedPayments,
      recentTransactions,
      monthlySpending,
    }

    return res.status(200).json(stats)
  } catch (error) {
    console.error('Error fetching financial stats:', error)
    return res.status(500).json({ message: 'Internal server error' })
  }
}