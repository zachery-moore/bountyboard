import { NextApiRequest, NextApiResponse } from 'next';
import { createClient } from '@/util/supabase/api';
import prisma from '@/lib/prisma';
import stripe from '@/lib/stripe';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const supabase = createClient(req, res);
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    // Get user profile to check if they're a studio
    const userProfile = await prisma.user.findUnique({
      where: { id: user.id },
      include: {
        studioProfile: true,
      },
    });

    if (!userProfile || userProfile.role !== 'STUDIO') {
      return res.status(403).json({ error: 'Only studio accounts can setup banking' });
    }

    let stripeAccountId = userProfile.studioProfile?.stripeAccountId;

    // Always try to retrieve the account first to check if it exists and its mode
    if (stripeAccountId) {
      try {
        const existingAccount = await stripe.accounts.retrieve(stripeAccountId);
        // If the account is in live mode and we're using test key (or vice versa), clear the ID
        if (existingAccount.livemode !== stripe.getClientOptions().apiKey?.startsWith('sk_live_')) {
          stripeAccountId = null;
          // Update the studio profile to clear the mismatched account ID
          if (userProfile.studioProfile) {
            await prisma.studioProfile.update({
              where: { id: userProfile.studioProfile.id },
              data: { stripeAccountId: null },
            });
          }
        }
      } catch (error) {
        // If we can't retrieve the account, clear the ID
        stripeAccountId = null;
        if (userProfile.studioProfile) {
          await prisma.studioProfile.update({
            where: { id: userProfile.studioProfile.id },
            data: { stripeAccountId: null },
          });
        }
      }
    }

    // If no valid Stripe account exists, create one
    if (!stripeAccountId) {
      const account = await stripe.accounts.create({
        type: 'express',
        country: 'US', // Default to US, you might want to make this dynamic
        email: user.email || undefined,
        capabilities: {
          transfers: { requested: true },
          card_payments: { requested: true },
        },
      });

      stripeAccountId = account.id;

      // Update or create studio profile with Stripe account ID
      if (userProfile.studioProfile) {
        await prisma.studioProfile.update({
          where: { id: userProfile.studioProfile.id },
          data: { stripeAccountId: account.id },
        });
      } else {
        await prisma.studioProfile.create({
          data: {
            userId: user.id,
            studioName: userProfile.name || 'New Studio',
            stripeAccountId: account.id,
            verified: false,
            totalSpent: 0,
            questsPosted: 0
          },
        });
      }
    }

    // Create an account link for onboarding
    const accountLink = await stripe.accountLinks.create({
      account: stripeAccountId,
      refresh_url: `${process.env.NEXT_PUBLIC_SITE_URL}/profile`,
      return_url: `${process.env.NEXT_PUBLIC_SITE_URL}/profile`,
      type: 'account_onboarding',
    });

    return res.json({ url: accountLink.url });
  } catch (error) {
    console.error('Banking setup error:', error);
    return res.status(500).json({ 
      error: 'Failed to setup banking',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}