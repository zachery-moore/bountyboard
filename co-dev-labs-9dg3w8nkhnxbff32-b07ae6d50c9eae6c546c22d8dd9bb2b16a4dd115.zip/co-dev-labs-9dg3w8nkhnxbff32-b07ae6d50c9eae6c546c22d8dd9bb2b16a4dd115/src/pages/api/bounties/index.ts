import { NextApiRequest, NextApiResponse } from 'next'
import prisma from '@/lib/prisma'
import { createClient } from '@/util/supabase/api'
import { BountyDifficulty, BountyStatus, SkillCategory, PaymentType } from '@prisma/client'

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const supabase = createClient(req, res)
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return res.status(401).json({ message: 'Unauthorized' })
  }

  // Helper function to check if user is the bounty owner
  const isBountyOwner = async (questId: string) => {
    const quest = await prisma.bounty.findUnique({
      where: { id: questId },
      select: { posterId: true }
    })
    return quest?.posterId === user.id
  }

  // GET /api/bounties - List all bounties
  if (req.method === 'GET') {
    try {
      const bounties = await prisma.bounty.findMany({
        include: {
          poster: {
            select: {
              name: true,
              studioProfile: {
                select: {
                  studioName: true,
                  verified: true
                }
              }
            }
          }
        },
        orderBy: {
          createdAt: 'desc'
        }
      })
      return res.status(200).json(bounties)
    } catch (error) {
      console.error('Error fetching bounties:', error)
      return res.status(500).json({ message: 'Error fetching bounties' })
    }
  }

  // POST /api/bounties - Create a new bounty
  if (req.method === 'POST') {
    try {
      // Get user profile to verify they are a studio
      const userProfile = await prisma.user.findUnique({
        where: { id: user.id },
        include: { studioProfile: true }
      })

      if (!userProfile || !userProfile.studioProfile) {
        return res.status(403).json({ message: 'Only studios can create bounties' })
      }

      const {
        title,
        description,
        category,
        difficulty,
        monetaryReward,
        coinReward,
        deadline,
        maxAssignees,
        requirements,
        deliverables
      } = req.body

      // Validate required fields
      if (!title || !description || !category || !difficulty || !deadline || !monetaryReward) {
        return res.status(400).json({ 
          message: 'Missing required fields. Please provide title, description, category, difficulty, deadline, and monetary reward.' 
        })
      }

      // Validate category and difficulty enums
      if (!Object.values(SkillCategory).includes(category)) {
        return res.status(400).json({ message: 'Invalid category value' })
      }

      if (!Object.values(BountyDifficulty).includes(difficulty)) {
        return res.status(400).json({ message: 'Invalid difficulty value' })
      }

      // Parse and validate monetary values
      const parsedMonetaryReward = parseFloat(String(monetaryReward))
      if (isNaN(parsedMonetaryReward) || parsedMonetaryReward < 0) {
        return res.status(400).json({ message: 'Invalid monetary reward value' })
      }

      // Parse and validate deadline
      const parsedDeadline = new Date(deadline)
      if (isNaN(parsedDeadline.getTime())) {
        return res.status(400).json({ message: 'Invalid deadline date format' })
      }

      if (parsedDeadline <= new Date()) {
        return res.status(400).json({ message: 'Deadline must be in the future' })
      }

      // Parse requirements into a proper JSON object
      let parsedRequirements = {}
      try {
        if (typeof requirements === 'string') {
          parsedRequirements = { details: requirements }
        } else if (typeof requirements === 'object' && requirements !== null) {
          parsedRequirements = requirements
        } else {
          parsedRequirements = { details: '' }
        }
      } catch (error) {
        console.error('Error parsing requirements:', error)
        parsedRequirements = { details: String(requirements || '') }
      }

      // Parse deliverables into string array
      const parsedDeliverables = Array.isArray(deliverables) 
        ? deliverables.map(String).filter(Boolean)
        : deliverables 
          ? [String(deliverables)].filter(Boolean)
          : []

      const bountyData = {
        title: String(title).trim(),
        description: String(description).trim(),
        posterId: user.id,
        difficulty: difficulty as BountyDifficulty,
        status: BountyStatus.OPEN,
        category: category as SkillCategory,
        deadline: parsedDeadline,
        monetaryReward: parsedMonetaryReward,
        coinReward: Math.max(0, parseInt(String(coinReward)) || 0),
        maxAssignees: Math.max(1, parseInt(String(maxAssignees)) || 1),
        requirements: parsedRequirements,
        deliverables: parsedDeliverables,
        totalBudget: parsedMonetaryReward,
        remainingBudget: parsedMonetaryReward,
        paymentType: PaymentType.MILESTONE
      }

      const [bounty] = await prisma.$transaction([
        prisma.bounty.create({
          data: bountyData
        }),
        prisma.studioProfile.update({
          where: { userId: user.id },
          data: {
            bountiesPosted: {
              increment: 1
            }
          }
        })
      ])

      return res.status(201).json(bounty)
    } catch (error) {
      console.error('Error creating bounty:', error)
      if (error instanceof Error) {
        return res.status(500).json({ message: `Error creating bounty: ${error.message}` })
      }
      return res.status(500).json({ message: 'Error creating bounty' })
    }
  }

  // DELETE /api/bounties?id={bountyId} - Delete a bounty
  if (req.method === 'DELETE') {
    try {
      const { id } = req.query

      if (!id || typeof id !== 'string') {
        return res.status(400).json({ message: 'Bounty ID is required' })
      }

      if (!await isBountyOwner(id)) {
        return res.status(403).json({ message: 'Not authorized to delete this bounty' })
      }

      await prisma.bounty.delete({
        where: { id }
      })

      return res.status(200).json({ message: 'Bounty deleted successfully' })
    } catch (error) {
      console.error('Error deleting bounty:', error)
      return res.status(500).json({ message: 'Error deleting bounty' })
    }
  }

  // PUT /api/bounties?id={bountyId} - Update a bounty
  if (req.method === 'PUT') {
    try {
      const { id } = req.query

      if (!id || typeof id !== 'string') {
        return res.status(400).json({ message: 'Bounty ID is required' })
      }

      if (!await isBountyOwner(id)) {
        return res.status(403).json({ message: 'Not authorized to edit this bounty' })
      }

      const {
        title,
        description,
        category,
        difficulty,
        monetaryReward,
        coinReward,
        deadline,
        maxAssignees,
        requirements,
        deliverables
      } = req.body

      const bounty = await prisma.bounty.update({
        where: { id },
        data: {
          title,
          description,
          difficulty: difficulty as BountyDifficulty,
          category: category as SkillCategory,
          deadline: new Date(deadline),
          monetaryReward,
          coinReward,
          maxAssignees,
          requirements,
          deliverables
        }
      })

      return res.status(200).json(bounty)
    } catch (error) {
      console.error('Error updating bounty:', error)
      return res.status(500).json({ message: 'Error updating bounty' })
    }
  }

  return res.status(405).json({ message: 'Method not allowed' })
}