import { NextApiRequest, NextApiResponse } from 'next'
import { createClient } from '@/util/supabase/api'
import prisma from '@/lib/prisma'

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' })
  }

  const bountyId = req.query.id as string

  if (!bountyId) {
    return res.status(400).json({ message: 'Bounty ID is required' })
  }

  try {
    const supabase = createClient(req, res)
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return res.status(401).json({ message: 'Unauthorized' })
    }

    const applications = await prisma.bountyApplication.findMany({
      where: {
        bountyId: bountyId,
      },
      include: {
        applicant: {
          include: {
            profile: true,
          },
        },
      },
    })

    return res.status(200).json(applications)
  } catch (error) {
    console.error('Error fetching applications:', error)
    return res.status(500).json({ message: 'Internal server error' })
  }
}