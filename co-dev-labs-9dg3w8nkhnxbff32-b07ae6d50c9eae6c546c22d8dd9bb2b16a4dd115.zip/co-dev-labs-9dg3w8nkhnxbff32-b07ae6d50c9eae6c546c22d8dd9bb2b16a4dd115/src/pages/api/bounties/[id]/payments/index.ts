import { NextApiRequest, NextApiResponse } from 'next'
import prisma from '@/lib/prisma'
import { createClient } from '@/util/supabase/api'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query
  const supabase = createClient(req, res)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return res.status(401).json({ error: 'Unauthorized' })
  }

  if (req.method === 'GET') {
    try {
      const payments = await prisma.payment.findMany({
        where: {
          bountyId: id as string,
        },
        include: {
          milestone: true,
        },
      })
      return res.status(200).json(payments)
    } catch (error) {
      return res.status(500).json({ error: 'Failed to fetch payments' })
    }
  }

  if (req.method === 'POST') {
    try {
      // Verify that the user is the bounty poster
      const bounty = await prisma.bounty.findUnique({
        where: { id: id as string },
        select: { 
          posterId: true, 
          totalBudget: true,
          remainingBudget: true
        },
      })

      if (!bounty) {
        return res.status(404).json({ error: 'Bounty not found' })
      }

      if (bounty.posterId !== user.id) {
        return res.status(403).json({ error: 'Only bounty poster can create payments' })
      }

      const { amount, milestoneId, description } = req.body

      // Check if there's enough budget
      if (amount > bounty.remainingBudget) {
        return res.status(400).json({ error: 'Insufficient remaining budget' })
      }

      // Create payment and update remaining budget
      const payment = await prisma.$transaction(async (prisma) => {
        const payment = await prisma.payment.create({
          data: {
            bountyId: id as string,
            amount,
            milestoneId,
            description,
          },
        })

        await prisma.bounty.update({
          where: { id: id as string },
          data: {
            remainingBudget: bounty.remainingBudget - amount,
          },
        })

        if (milestoneId) {
          await prisma.milestone.update({
            where: { id: milestoneId },
            data: {
              status: 'COMPLETED',
            },
          })
        }

        return payment
      })

      return res.status(201).json(payment)
    } catch (error) {
      return res.status(500).json({ error: 'Failed to create payment' })
    }
  }

  return res.status(405).json({ error: 'Method not allowed' })
}