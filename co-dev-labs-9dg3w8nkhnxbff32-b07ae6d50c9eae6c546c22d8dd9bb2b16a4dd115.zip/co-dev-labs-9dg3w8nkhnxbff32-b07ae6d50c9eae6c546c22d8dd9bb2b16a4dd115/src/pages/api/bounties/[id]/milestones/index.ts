import { NextApiRequest, NextApiResponse } from 'next'
import prisma from '@/lib/prisma'
import { createClient } from '@/util/supabase/api'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query
  const supabase = createClient(req, res)
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return res.status(401).json({ error: 'Unauthorized' })
  }

  if (req.method === 'GET') {
    try {
      const milestones = await prisma.milestone.findMany({
        where: {
          bountyId: id as string,
        },
        orderBy: {
          order: 'asc',
        },
        include: {
          payments: true,
        },
      })
      return res.status(200).json(milestones)
    } catch (error) {
      return res.status(500).json({ error: 'Failed to fetch milestones' })
    }
  }

  if (req.method === 'POST') {
    try {
      // Verify that the user is the bounty poster
      const bounty = await prisma.bounty.findUnique({
        where: { id: id as string },
        select: { posterId: true, totalBudget: true },
      })

      if (!bounty) {
        return res.status(404).json({ error: 'Bounty not found' })
      }

      if (bounty.posterId !== user.id) {
        return res.status(403).json({ error: 'Only bounty poster can create milestones' })
      }

      const { title, description, amount, dueDate } = req.body

      // Get the highest order number
      const lastMilestone = await prisma.milestone.findFirst({
        where: { bountyId: id as string },
        orderBy: { order: 'desc' },
      })

      const newOrder = lastMilestone ? lastMilestone.order + 1 : 1

      const milestone = await prisma.milestone.create({
        data: {
          bountyId: id as string,
          title,
          description,
          amount,
          dueDate: new Date(dueDate),
          order: newOrder,
        },
      })

      return res.status(201).json(milestone)
    } catch (error) {
      return res.status(500).json({ error: 'Failed to create milestone' })
    }
  }

  return res.status(405).json({ error: 'Method not allowed' })
}