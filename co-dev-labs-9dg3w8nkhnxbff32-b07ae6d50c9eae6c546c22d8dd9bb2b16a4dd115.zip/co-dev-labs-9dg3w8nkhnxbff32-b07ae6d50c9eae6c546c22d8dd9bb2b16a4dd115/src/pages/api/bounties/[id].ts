import { NextApiRequest, NextApiResponse } from 'next'
import prisma from '@/lib/prisma'
import { createClient } from '@/util/supabase/api'

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // Only require authentication for PUT requests
  if (req.method === 'PUT') {
    const supabase = createClient(req, res)
    const { data: { user }, error: authError } = await supabase.auth.getUser()

    if (authError || !user) {
      return res.status(401).json({ message: 'Unauthorized' })
    }
  }

  const { id } = req.query

  if (!id || typeof id !== 'string') {
    console.error('Invalid or missing bounty ID:', id);
    return res.status(400).json({ message: 'Invalid or missing bounty ID' })
  }

  // GET /api/bounties/[id] - Get bounty details
  if (req.method === 'GET') {
    try {
      const bounty = await prisma.bounty.findUnique({
        where: { id },
        include: {
          poster: {
            select: {
              id: true,
              name: true,
              studioProfile: {
                select: {
                  studioName: true,
                  verified: true
                }
              },
              profile: {
                select: {
                  title: true
                }
              }
            }
          },
          milestones: {
            select: {
              id: true,
              title: true,
              description: true,
              amount: true,
              status: true,
              dueDate: true,
              order: true,
              payments: {
                select: {
                  id: true,
                  amount: true,
                  status: true
                }
              }
            },
            orderBy: {
              order: 'asc'
            }
          },
          applications: {
            select: {
              id: true,
              status: true,
              coverLetter: true,
              createdAt: true,
              applicant: {
                select: {
                  id: true,
                  name: true,
                  profile: {
                    select: {
                      title: true
                    }
                  }
                }
              }
            }
          }
        }
      })

      if (!bounty) {
        return res.status(404).json({ message: 'Bounty not found' })
      }

      // Transform the data to ensure all required fields are present and properly structured
      const transformedBounty = {
        id: bounty.id,
        title: bounty.title || '',
        description: bounty.description || '',
        posterId: bounty.posterId || '',
        difficulty: bounty.difficulty || 'EASY',
        status: bounty.status || 'OPEN',
        category: bounty.category || 'OTHER',
        deadline: bounty.deadline ? bounty.deadline.toISOString() : new Date().toISOString(),
        requirements: bounty.requirements ? 
          (typeof bounty.requirements === 'string' ? bounty.requirements : JSON.stringify(bounty.requirements)) 
          : '',
        deliverables: Array.isArray(bounty.deliverables) ? bounty.deliverables : [],
        poster: bounty.poster ? {
          id: bounty.poster.id,
          name: bounty.poster.name || null,
          studioProfile: bounty.poster.studioProfile ? {
            studioName: bounty.poster.studioProfile.studioName,
            verified: !!bounty.poster.studioProfile.verified
          } : null,
          profile: bounty.poster.profile ? {
            title: bounty.poster.profile.title || null
          } : null
        } : null,
        monetaryReward: Number(bounty.monetaryReward || 0),
        coinReward: Number(bounty.coinReward || 0),
        totalBudget: Number(bounty.totalBudget || 0),
        remainingBudget: Number(bounty.remainingBudget || 0),
        milestones: (bounty.milestones || []).map(milestone => ({
          id: milestone.id,
          title: milestone.title || '',
          description: milestone.description || '',
          amount: Number(milestone.amount || 0),
          status: milestone.status || 'PENDING',
          dueDate: milestone.dueDate ? milestone.dueDate.toISOString() : new Date().toISOString(),
          order: Number(milestone.order || 0)
        })),
        applications: (bounty.applications || []).map(app => ({
          id: app.id,
          status: app.status || 'PENDING',
          applicantId: app.applicant?.id || '',
          coverLetter: '',
          createdAt: app.createdAt ? app.createdAt.toISOString() : new Date().toISOString()
        }))
      }

      return res.status(200).json(transformedBounty)
    } catch (error) {
      console.error('Error fetching bounty:', error)
      return res.status(500).json({ 
        message: 'Error fetching bounty',
        error: error instanceof Error ? error.message : 'Unknown error'
      })
    }
  }

  // PUT /api/bounties/[id] - Update bounty
  if (req.method === 'PUT') {
    try {
      // First check if the user owns this bounty
      const bounty = await prisma.bounty.findUnique({
        where: { id },
        select: { posterId: true }
      })

      if (!bounty) {
        return res.status(404).json({ message: 'Bounty not found' })
      }

      if (bounty.posterId !== user.id) {
        return res.status(403).json({ message: 'Not authorized to edit this bounty' })
      }

      const updatedBounty = await prisma.bounty.update({
        where: { id },
        data: {
          title: req.body.title,
          description: req.body.description,
          difficulty: req.body.difficulty,
          category: req.body.category,
          monetaryReward: Number(req.body.monetaryReward) || 0,
          coinReward: Number(req.body.coinReward) || 0,
          deadline: new Date(req.body.deadline),
          requirements: req.body.requirements || '',
          deliverables: Array.isArray(req.body.deliverables) ? req.body.deliverables : []
        }
      })

      return res.status(200).json(updatedBounty)
    } catch (error) {
      console.error('Error updating bounty:', error)
      return res.status(500).json({ 
        message: 'Error updating bounty',
        error: error instanceof Error ? error.message : 'Unknown error'
      })
    }
  }

  return res.status(405).json({ message: 'Method not allowed' })
}