import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '@/lib/prisma';
import { createClient } from '@/util/supabase/api';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { method } = req;
  const { id } = req.query;
  const supabase = createClient(req, res);

  // Check authentication
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error || !user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  switch (method) {
    case 'GET':
      try {
        const application = await prisma.bountyApplication.findUnique({
          where: { id: String(id) },
          include: {
            bounty: true,
            applicant: {
              include: {
                profile: true
              }
            }
          }
        });

        if (!application) {
          return res.status(404).json({ error: 'Application not found' });
        }

        // Check if user has permission to view this application
        if (application.applicantId !== user.id && application.bounty.posterId !== user.id) {
          return res.status(403).json({ error: 'Forbidden' });
        }

        return res.status(200).json(application);
      } catch (error) {
        return res.status(500).json({ error: 'Error fetching application' });
      }

    case 'PATCH':
      try {
        const { status } = req.body;

        const application = await prisma.bountyApplication.findUnique({
          where: { id: String(id) },
          include: { bounty: true }
        });

        if (!application) {
          return res.status(404).json({ error: 'Application not found' });
        }

        // Only bounty poster can update status (except for WITHDRAWN)
        if (status !== 'WITHDRAWN' && application.bounty.posterId !== user.id) {
          return res.status(403).json({ error: 'Forbidden' });
        }

        // Only applicant can withdraw their application
        if (status === 'WITHDRAWN' && application.applicantId !== user.id) {
          return res.status(403).json({ error: 'Forbidden' });
        }

        // If accepting application, create bounty assignment
        if (status === 'ACCEPTED') {
          // Start a transaction to handle both application update and assignment creation
          const result = await prisma.$transaction(async (prisma) => {
            // Update application status
            const updatedApplication = await prisma.bountyApplication.update({
              where: { id: String(id) },
              data: { status }
            });

            // Create bounty assignment
            await prisma.bountyAssignment.create({
              data: {
                bountyId: application.bountyId,
                assigneeId: application.applicantId,
                status: 'IN_PROGRESS'
              }
            });

            // Update bounty status
            await prisma.bounty.update({
              where: { id: application.bountyId },
              data: { status: 'IN_PROGRESS' }
            });

            return updatedApplication;
          });

          return res.status(200).json(result);
        }

        // For other status updates
        const updatedApplication = await prisma.bountyApplication.update({
          where: { id: String(id) },
          data: { status }
        });

        return res.status(200).json(updatedApplication);
      } catch (error) {
        return res.status(500).json({ error: 'Error updating application' });
      }

    case 'DELETE':
      try {
        const application = await prisma.bountyApplication.findUnique({
          where: { id: String(id) },
          include: { bounty: true }
        });

        if (!application) {
          return res.status(404).json({ error: 'Application not found' });
        }

        // Only the applicant or bounty poster can delete the application
        if (application.applicantId !== user.id && application.bounty.posterId !== user.id) {
          return res.status(403).json({ error: 'Forbidden' });
        }

        await prisma.bountyApplication.delete({
          where: { id: String(id) }
        });

        return res.status(200).json({ message: 'Application deleted successfully' });
      } catch (error) {
        return res.status(500).json({ error: 'Error deleting application' });
      }

    default:
      res.setHeader('Allow', ['GET', 'PATCH', 'DELETE']);
      return res.status(405).json({ error: `Method ${method} Not Allowed` });
  }
}