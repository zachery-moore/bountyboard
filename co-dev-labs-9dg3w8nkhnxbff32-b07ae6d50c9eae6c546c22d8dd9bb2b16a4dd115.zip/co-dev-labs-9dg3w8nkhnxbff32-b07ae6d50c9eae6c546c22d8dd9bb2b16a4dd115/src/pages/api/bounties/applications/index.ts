import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '@/lib/prisma';
import { createClient } from '@/util/supabase/api';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { method } = req;
  const supabase = createClient(req, res);

  // Check authentication
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error || !user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  switch (method) {
    case 'GET':
      try {
        const applications = await prisma.bountyApplication.findMany({
          where: {
            OR: [
              { applicantId: user.id },
              {
                bounty: {
                  posterId: user.id
                }
              }
            ]
          },
          include: {
            bounty: true,
            applicant: {
              include: {
                profile: true
              }
            }
          }
        });
        return res.status(200).json(applications);
      } catch (error) {
        return res.status(500).json({ error: 'Error fetching applications' });
      }

    case 'POST':
      try {
        const { bountyId, coverLetter, portfolio } = req.body;

        // Verify bounty exists and is open
        const bounty = await prisma.bounty.findUnique({
          where: { id: bountyId }
        });

        if (!bounty) {
          return res.status(404).json({ error: 'Bounty not found' });
        }

        if (bounty.status !== 'OPEN') {
          return res.status(400).json({ error: 'Bounty is not open for applications' });
        }

        // Check if user already applied
        const existingApplication = await prisma.bountyApplication.findUnique({
          where: {
            bountyId_applicantId: {
              bountyId,
              applicantId: user.id
            }
          }
        });

        if (existingApplication) {
          return res.status(400).json({ error: 'You have already applied to this bounty' });
        }

        const application = await prisma.bountyApplication.create({
          data: {
            bountyId,
            applicantId: user.id,
            coverLetter,
            portfolio,
          }
        });

        return res.status(201).json(application);
      } catch (error) {
        return res.status(500).json({ error: 'Error creating application' });
      }

    default:
      res.setHeader('Allow', ['GET', 'POST']);
      return res.status(405).json({ error: `Method ${method} Not Allowed` });
  }
}