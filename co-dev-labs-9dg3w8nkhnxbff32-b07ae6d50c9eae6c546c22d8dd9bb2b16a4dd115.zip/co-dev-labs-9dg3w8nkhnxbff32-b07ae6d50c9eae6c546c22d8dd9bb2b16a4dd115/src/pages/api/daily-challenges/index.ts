import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '@/lib/prisma';
import { createClient } from '@/util/supabase/api';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const supabase = createClient(req, res);
  const { data: { user }, error } = await supabase.auth.getUser();

  if (error || !user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (req.method === 'GET') {
    try {
      // Get current date at midnight UTC
      const today = new Date();
      today.setUTCHours(0, 0, 0, 0);
      
      // Get tomorrow at midnight UTC
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      // Get active challenges for the user
      const userChallenges = await prisma.userDailyChallenge.findMany({
        where: {
          userId: user.id,
          challenge: {
            createdAt: {
              gte: today,
              lt: tomorrow
            }
          }
        },
        include: {
          challenge: true
        }
      });

      // If user has no challenges for today, generate new ones
      if (userChallenges.length === 0) {
        // Create some sample challenges
        const challenges = [
          {
            title: 'Bounty Hunter',
            description: 'Apply to 3 bounties today',
            xpReward: 100,
            coinReward: 50,
            type: 'APPLY_BOUNTY',
            requirement: 3,
            expiresAt: tomorrow
          },
          {
            title: 'Milestone Master',
            description: 'Complete 2 milestones',
            xpReward: 150,
            coinReward: 75,
            type: 'COMPLETE_MILESTONE',
            requirement: 2,
            expiresAt: tomorrow
          },
          {
            title: 'Quick Response',
            description: 'Submit work within 4 hours of accepting a bounty',
            xpReward: 200,
            coinReward: 100,
            type: 'SUBMIT_WORK',
            requirement: 1,
            expiresAt: tomorrow
          }
        ];

        // Create challenges and assign to user
        const createdChallenges = await Promise.all(
          challenges.map(async (challenge) => {
            const newChallenge = await prisma.dailyChallenge.create({
              data: challenge
            });

            return prisma.userDailyChallenge.create({
              data: {
                userId: user.id,
                challengeId: newChallenge.id
              },
              include: {
                challenge: true
              }
            });
          })
        );

        return res.status(200).json(createdChallenges);
      }

      return res.status(200).json(userChallenges);
    } catch (error) {
      console.error('Error handling daily challenges:', error);
      return res.status(500).json({ error: 'Internal server error' });
    }
  }

  if (req.method === 'POST') {
    try {
      const { challengeId } = req.body;

      if (!challengeId) {
        return res.status(400).json({ error: 'Challenge ID is required' });
      }

      const userChallenge = await prisma.userDailyChallenge.findFirst({
        where: {
          userId: user.id,
          challengeId: challengeId,
          completed: false
        },
        include: {
          challenge: true
        }
      });

      if (!userChallenge) {
        return res.status(404).json({ error: 'Challenge not found' });
      }

      // Update progress
      const updatedProgress = userChallenge.progress + 1;
      const isCompleted = updatedProgress >= userChallenge.challenge.requirement;

      const updatedChallenge = await prisma.userDailyChallenge.update({
        where: {
          id: userChallenge.id
        },
        data: {
          progress: updatedProgress,
          completed: isCompleted,
          completedAt: isCompleted ? new Date() : null
        },
        include: {
          challenge: true
        }
      });

      // If challenge is completed, award XP and coins
      if (isCompleted) {
        await prisma.user.update({
          where: {
            id: user.id
          },
          data: {
            xp: {
              increment: userChallenge.challenge.xpReward
            },
            guildCoins: {
              increment: userChallenge.challenge.coinReward
            }
          }
        });
      }

      return res.status(200).json(updatedChallenge);
    } catch (error) {
      console.error('Error updating challenge progress:', error);
      return res.status(500).json({ error: 'Internal server error' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}