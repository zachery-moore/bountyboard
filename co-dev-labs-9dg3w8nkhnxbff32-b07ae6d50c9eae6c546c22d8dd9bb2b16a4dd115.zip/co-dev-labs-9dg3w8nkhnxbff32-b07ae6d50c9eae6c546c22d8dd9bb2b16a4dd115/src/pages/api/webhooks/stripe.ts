import { NextApiRequest, NextApiResponse } from 'next';
import { buffer } from 'micro';
import Stripe from 'stripe';
import prisma from '@/lib/prisma';
import { stripe } from '@/lib/stripe';

export const config = {
  api: {
    bodyParser: false,
  },
};

async function handlePaymentIntentSucceeded(event: Stripe.Event) {
  const paymentIntent = event.data.object as Stripe.PaymentIntent;
  
  // Update payment status in database
  const payment = await prisma.payment.update({
    where: {
      stripePaymentIntentId: paymentIntent.id,
    },
    data: {
      status: 'COMPLETED',
      processedAt: new Date(),
      webhookEvents: {
        create: {
          eventType: event.type,
          eventData: event.data.object as any,
        },
      },
    },
    include: {
      bounty: true,
      milestone: true,
    },
  });

  // If this is a milestone payment, update milestone status
  if (payment.milestone) {
    await prisma.milestone.update({
      where: { id: payment.milestone.id },
      data: { status: 'COMPLETED' },
    });
  }

  // Update bounty status if needed
  const allMilestonesCompleted = await prisma.milestone.findMany({
    where: {
      bountyId: payment.bountyId,
      status: { not: 'COMPLETED' },
    },
  });

  if (allMilestonesCompleted.length === 0) {
    await prisma.bounty.update({
      where: { id: payment.bountyId },
      data: { status: 'COMPLETED' },
    });
  }
}

async function handlePaymentIntentFailed(event: Stripe.Event) {
  const paymentIntent = event.data.object as Stripe.PaymentIntent;
  
  await prisma.payment.update({
    where: {
      stripePaymentIntentId: paymentIntent.id,
    },
    data: {
      status: 'FAILED',
      webhookEvents: {
        create: {
          eventType: event.type,
          eventData: event.data.object as any,
        },
      },
    },
  });
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  const sig = req.headers['stripe-signature'] as string;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!webhookSecret) {
    return res.status(500).json({ message: 'Webhook secret not configured' });
  }

  try {
    const buf = await buffer(req);
    const event = stripe.webhooks.constructEvent(buf, sig, webhookSecret);

    switch (event.type) {
      case 'payment_intent.succeeded':
        await handlePaymentIntentSucceeded(event);
        break;
      case 'payment_intent.payment_failed':
        await handlePaymentIntentFailed(event);
        break;
      default:
        console.log(`Unhandled event type ${event.type}`);
    }

    res.json({ received: true });
  } catch (err) {
    console.error('Webhook error:', err);
    res.status(400).send(`Webhook Error: ${err.message}`);
  }
}