import { NextApiRequest, NextApiResponse } from 'next';
import { createClient } from '@/util/supabase/api';
import prisma from '@/lib/prisma';
import { ThemeType, UserType } from '@prisma/client';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const supabase = createClient(req, res);
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      console.error('Auth error:', authError);
      return res.status(401).json({ message: 'Unauthorized' });
    }

    try {
      // First try to find by ID
      let profile = await prisma.user.findUnique({
        where: {
          id: user.id,
        },
        include: {
          profile: true,
          studioProfile: true,
          achievements: {
            include: {
              achievement: true,
            },
          },
        },
      });

      // If no profile found, try to find by email
      if (!profile && user.email) {
        profile = await prisma.user.findUnique({
          where: {
            email: user.email,
          },
          include: {
            profile: true,
            studioProfile: true,
            achievements: {
              include: {
                achievement: true,
              },
            },
          },
        });

        // If found by email but ID doesn't match, update the ID
        if (profile && profile.id !== user.id) {
          profile = await prisma.user.update({
            where: { id: profile.id },
            data: { id: user.id },
            include: {
              profile: true,
              studioProfile: true,
              achievements: {
                include: {
                  achievement: true,
                },
              },
            },
          });
        }
      }

      // If still no profile, create a new one
      if (!profile) {
        // Get user role from metadata, ensuring it's properly capitalized
        let userRole = (user.user_metadata?.role || 'CREATOR').toUpperCase();
        // Validate userRole is either CREATOR or STUDIO
        userRole = ['CREATOR', 'STUDIO'].includes(userRole) ? userRole : 'CREATOR';
        const displayName = user.user_metadata?.name || user.email?.split('@')[0] || 'New User';
        
        console.log('Creating new profile with role:', userRole);

        try {
          if (userRole === 'CREATOR') {
            profile = await prisma.user.create({
              data: {
                id: user.id,
                email: user.email || '',
                role: UserType.CREATOR,
                name: displayName,
                level: 1,
                xp: 0,
                guildCoins: 0,
                theme: ThemeType.FANTASY,
                profile: {
                  create: {
                    totalEarned: 0,
                    questsCompleted: 0,
                    availability: true,
                    averageRating: 0,
                    successRate: 0,
                    specialties: [],
                    portfolioItems: []
                  }
                }
              },
              include: {
                profile: true,
                studioProfile: true,
                achievements: {
                  include: {
                    achievement: true,
                  },
                },
              },
            });
          } else {
            profile = await prisma.user.create({
              data: {
                id: user.id,
                email: user.email || '',
                role: UserType.STUDIO,
                name: displayName,
                level: 1,
                xp: 0,
                guildCoins: 0,
                theme: ThemeType.FANTASY,
                studioProfile: {
                  create: {
                    studioName: displayName,
                    verified: false,
                    totalSpent: 0,
                    questsPosted: 0
                  }
                }
              },
              include: {
                profile: true,
                studioProfile: true,
                achievements: {
                  include: {
                    achievement: true,
                  },
                },
              },
            });
          }

          // Handle initial achievement
          try {
            let achievement = await prisma.achievement.findFirst({
              where: {
                title: 'New Adventurer'
              }
            });

            if (!achievement) {
              achievement = await prisma.achievement.create({
                data: {
                  title: 'New Adventurer',
                  description: 'Joined the Quest Board for the first time',
                  xpReward: 100,
                  coinReward: 50,
                  icon: '🌟',
                  isSecret: false
                }
              });
            }

            const existingUserAchievement = await prisma.userAchievement.findFirst({
              where: {
                userId: profile.id,
                achievementId: achievement.id
              }
            });

            if (!existingUserAchievement) {
              await prisma.userAchievement.create({
                data: {
                  userId: profile.id,
                  achievementId: achievement.id
                }
              });
            }
          } catch (achievementError) {
            console.error('Achievement creation error:', achievementError);
          }
        } catch (profileCreationError) {
          console.error('Profile creation error:', profileCreationError);
          return res.status(500).json({ 
            message: 'Failed to create user profile',
            details: profileCreationError instanceof Error ? profileCreationError.message : 'Unknown error'
          });
        }
      }

      if (!profile) {
        return res.status(404).json({ message: 'Profile not found' });
      }

      // Transform the data to include role-specific information
      const transformedProfile = {
        ...profile,
        profileData: profile.role === UserType.CREATOR ? profile.profile : profile.studioProfile,
      };

      // Remove the individual profile objects to clean up the response
      delete transformedProfile.profile;
      delete transformedProfile.studioProfile;

      return res.status(200).json(transformedProfile);
    } catch (profileFetchError) {
      console.error('Profile fetch error:', profileFetchError);
      return res.status(500).json({ 
        message: 'Failed to fetch user profile',
        details: profileFetchError instanceof Error ? profileFetchError.message : 'Unknown error'
      });
    }
  } catch (error) {
    console.error('General error:', error);
    return res.status(500).json({ 
      message: 'Internal server error',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}