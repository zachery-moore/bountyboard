import { NextApiRequest, NextApiResponse } from 'next';
import stripe from '@/lib/stripe';
import { createClient } from '@/util/supabase/api';
import prisma from '@/lib/prisma';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const supabase = createClient(req, res);
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    const { amount, bountyId } = req.body;

    if (!amount || !bountyId) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    // Get the bounty to verify it exists and get creator details
    const bounty = await prisma.bounty.findUnique({
      where: { id: bountyId },
      include: { creator: true }
    });

    if (!bounty) {
      return res.status(404).json({ message: 'Bounty not found' });
    }

    // Create a Payment Intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount * 100, // Convert to cents
      currency: 'usd',
      metadata: {
        bountyId,
        userId: session.user.id,
      },
      automatic_payment_methods: {
        enabled: true,
      },
    });

    return res.status(200).json({
      clientSecret: paymentIntent.client_secret,
    });
  } catch (error) {
    console.error('Payment intent creation error:', error);
    return res.status(500).json({ message: 'Error creating payment intent' });
  }
}