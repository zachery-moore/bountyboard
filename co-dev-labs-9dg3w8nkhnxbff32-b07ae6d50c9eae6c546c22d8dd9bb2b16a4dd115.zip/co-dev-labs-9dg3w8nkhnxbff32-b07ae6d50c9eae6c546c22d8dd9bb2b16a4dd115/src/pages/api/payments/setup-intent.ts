import { NextApiRequest, NextApiResponse } from 'next';
import { createClient } from '@/util/supabase/api';
import { stripe } from '@/lib/stripe';
import prisma from '@/lib/prisma';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  const supabase = createClient(req, res);
  const { data: { user }, error } = await supabase.auth.getUser();

  if (error || !user) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  try {
    // Check if user is a studio
    const studioProfile = await prisma.studioProfile.findUnique({
      where: { userId: user.id },
    });

    if (!studioProfile) {
      return res.status(403).json({ message: 'Only studio accounts can set up payment methods' });
    }

    // Check if studio already has a customer ID
    let studioPaymentMethod = await prisma.studioPaymentMethod.findUnique({
      where: { userId: user.id },
    });

    if (!studioPaymentMethod) {
      // Create a new Stripe customer
      const customer = await stripe.customers.create({
        email: user.email,
        metadata: {
          userId: user.id,
        },
      });

      // Save the customer ID
      studioPaymentMethod = await prisma.studioPaymentMethod.create({
        data: {
          userId: user.id,
          stripeCustomerId: customer.id,
        },
      });
    }

    // Create a SetupIntent
    const setupIntent = await stripe.setupIntents.create({
      customer: studioPaymentMethod.stripeCustomerId,
      payment_method_types: ['card'],
    });

    return res.json({
      clientSecret: setupIntent.client_secret,
    });
  } catch (err) {
    console.error('Setup intent error:', err);
    return res.status(500).json({ message: 'Error creating setup intent' });
  }
}