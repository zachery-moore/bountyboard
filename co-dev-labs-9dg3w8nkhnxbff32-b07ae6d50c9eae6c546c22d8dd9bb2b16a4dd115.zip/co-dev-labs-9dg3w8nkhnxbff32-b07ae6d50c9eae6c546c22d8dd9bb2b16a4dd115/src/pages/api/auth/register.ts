import { NextApiRequest, NextApiResponse } from 'next'
import prisma from '@/lib/prisma'
import { createClient } from '@/util/supabase/api'
import { SkillCategory, ThemeType } from '@prisma/client'

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' })
  }

  try {
    const { email, password, userType, displayName } = req.body
    console.log('Registration attempt for:', { email, userType, displayName })

    if (!email || !password || !userType || !displayName) {
      return res.status(400).json({ 
        message: 'Missing required fields',
        details: {
          email: !email,
          password: !password,
          userType: !userType,
          displayName: !displayName
        }
      })
    }

    // Validate userType
    if (!['CREATOR', 'STUDIO'].includes(userType)) {
      return res.status(400).json({ 
        message: 'Invalid user type',
        validTypes: ['CREATOR', 'STUDIO']
      })
    }

    // Initialize Supabase client
    const supabase = createClient(req, res)

    // Create new user in Supabase first
    const { data: { user }, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          role: userType,
          name: displayName
        },
        emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback`
      }
    })

    if (authError) {
      console.error('Supabase auth error:', authError)
      
      // Handle rate limiting error specifically
      if (authError.message.includes('rate limit') || authError.message.includes('after 58 seconds')) {
        return res.status(429).json({
          message: 'Please wait a minute before trying to register again.',
          isRateLimit: true
        })
      }

      return res.status(400).json({ 
        message: authError.message || 'Failed to create user account'
      })
    }

    if (!user) {
      return res.status(400).json({ 
        message: 'No user data returned from authentication service'
      })
    }

    const userId = user.id

    try {
      // Check if user already exists in Prisma
      const existingUser = await prisma.user.findUnique({
        where: { id: userId }
      });

      if (existingUser) {
        // If user exists in Prisma, clean up the Supabase user and ask to try again
        try {
          await supabase.auth.admin.deleteUser(userId);
        } catch (cleanupError) {
          console.error('Failed to cleanup Supabase user:', cleanupError);
        }
        return res.status(400).json({ 
          message: 'Please try registering again',
          details: 'A temporary error occurred during registration'
        });
      }

      // Create base user if it doesn't exist
      const newUser = await prisma.user.create({
        data: {
          id: userId,
          email,
          role: userType,
          name: displayName,
          level: 1,
          xp: 0,
          guildCoins: 0,
          theme: ThemeType.FANTASY
        }
      })

      // Create type-specific profile
      if (userType === 'CREATOR') {
        await prisma.creatorProfile.create({
          data: {
            userId: newUser.id,
            totalEarned: 0,
            questsCompleted: 0,
            availability: true,
            averageRating: 0,
            successRate: 0,
            specialties: [],
            portfolioItems: []
          }
        })
      } else {
        await prisma.studioProfile.create({
          data: {
            userId: newUser.id,
            studioName: displayName,
            verified: false,
            totalSpent: 0,
            bountiesPosted: 0
          }
        })
      }

      // Check if the achievement exists or create it
      let achievement = await prisma.achievement.findFirst({
        where: {
          title: 'New Adventurer'
        }
      });

      if (!achievement) {
        achievement = await prisma.achievement.create({
          data: {
            title: 'New Adventurer',
            description: 'Joined the Quest Board for the first time',
            xpReward: 100,
            coinReward: 50,
            icon: '🌟',
            isSecret: false
          }
        });
      }

      await prisma.userAchievement.create({
        data: {
          userId: newUser.id,
          achievementId: achievement.id
        }
      })

      console.log('User registration successful:', { userId: newUser.id })
      return res.status(200).json({ 
        message: 'User registered successfully',
        userId: newUser.id
      })

    } catch (dbError: any) {
      console.error('Database error details:', dbError)
      
      // Cleanup Supabase user if database operations failed
      try {
        await supabase.auth.admin.deleteUser(userId)
      } catch (cleanupError) {
        console.error('Failed to cleanup Supabase user:', cleanupError)
      }

      return res.status(500).json({ 
        message: 'Database error during registration',
        details: dbError.message
      })
    }

  } catch (error: any) {
    console.error('Registration error:', error)
    return res.status(500).json({ 
      message: 'Internal server error',
      details: error.message
    })
  }
}