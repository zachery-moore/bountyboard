import React, { useEffect, useState } from "react";
import Head from "next/head";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { useAuth } from "@/contexts/AuthContext";
import { useRouter } from "next/router";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { toast } from "@/components/ui/use-toast";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface PlatformStats {
  activeBounties: number;
  totalUsers: number;
  totalStudios: number;
  totalPayments: number;
}

export default function Home() {
  const { user } = useAuth();
  const router = useRouter();
  const [stats, setStats] = useState<PlatformStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      router.push('/dashboard');
    }
  }, [user, router]);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await fetch('/api/statistics/platform-stats');
        if (!response.ok) throw new Error('Failed to fetch stats');
        const data = await response.json();
        setStats(data);
      } catch (error) {
        console.error('Error fetching stats:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M+`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K+`;
    return `${num}+`;
  };

  const formatCurrency = (amount: number) => {
    const value = amount / 100; // Convert cents to dollars
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M+`;
    if (value >= 1000) return `$${(value / 1000).toFixed(1)}K+`;
    return `$${value}+`;
  };

  return (
    <>
      <Head>
        <title>BountyBoard - Creative Collaboration Platform</title>
        <meta name="description" content="Join the ultimate marketplace connecting game studios with creative talent. Complete bounties, earn rewards, and level up your career!" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <div className="bg-background min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">
          {/* Hero Section */}
          <div className="container mx-auto px-4 py-16 text-center">
            <Badge variant="secondary" className="mb-4">Now in Open Beta 🎯</Badge>
            <h1 className="text-4xl md:text-6xl font-bold text-primary mb-6">
              Where Creative Talent Meets Opportunity
            </h1>
            <p className="text-muted-foreground text-xl mb-8 max-w-2xl mx-auto">
              Join the innovative marketplace where game studios post creative work as bounties, and creators earn rewards while building their portfolio.
            </p>
            <div className="flex gap-4 justify-center mb-16">
              <Link href="/signup">
                <Button size="lg" className="text-lg">
                  Start Hunting Bounties
                </Button>
              </Link>
              <Link href="/login">
                <Button size="lg" variant="outline" className="text-lg">
                  Access Your Account
                </Button>
              </Link>
            </div>

            {/* Feature Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
              <Card className="bg-card hover:bg-accent transition-colors">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-2xl">💰</span> Lucrative Bounties
                  </CardTitle>
                  <CardDescription>
                    Studios post creative opportunities with competitive rewards
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="bg-card hover:bg-accent transition-colors">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-2xl">🏆</span> Build Your Reputation
                  </CardTitle>
                  <CardDescription>
                    Complete bounties, earn recognition, and showcase your expertise
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="bg-card hover:bg-accent transition-colors">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-2xl">🌟</span> Grow Your Career
                  </CardTitle>
                  <CardDescription>
                    Connect with top studios and unlock new opportunities
                  </CardDescription>
                </CardHeader>
              </Card>
            </div>

            {/* Stats Section */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              <Card className="bg-primary/10">
                <CardHeader>
                  {loading ? (
                    <Skeleton className="h-8 w-24 mx-auto" />
                  ) : (
                    <CardTitle className="text-primary">
                      {stats ? formatNumber(stats.activeBounties) : '0'}
                    </CardTitle>
                  )}
                  <CardDescription>Active Bounties</CardDescription>
                </CardHeader>
              </Card>
              
              <Card className="bg-primary/10">
                <CardHeader>
                  {loading ? (
                    <Skeleton className="h-8 w-24 mx-auto" />
                  ) : (
                    <CardTitle className="text-primary">
                      {stats ? formatNumber(stats.totalUsers) : '0'}
                    </CardTitle>
                  )}
                  <CardDescription>Creative Hunters</CardDescription>
                </CardHeader>
              </Card>

              <Card className="bg-primary/10">
                <CardHeader>
                  {loading ? (
                    <Skeleton className="h-8 w-24 mx-auto" />
                  ) : (
                    <CardTitle className="text-primary">
                      {stats ? formatNumber(stats.totalStudios) : '0'}
                    </CardTitle>
                  )}
                  <CardDescription>Game Studios</CardDescription>
                </CardHeader>
              </Card>

              <Card className="bg-primary/10">
                <CardHeader>
                  {loading ? (
                    <Skeleton className="h-8 w-24 mx-auto" />
                  ) : (
                    <CardTitle className="text-primary">
                      {stats ? formatCurrency(stats.totalPayments) : '$0'}
                    </CardTitle>
                  )}
                  <CardDescription>Rewards Paid</CardDescription>
                </CardHeader>
              </Card>
            </div>

            {/* How It Works Section */}
            <div className="py-16 bg-accent/20">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-center mb-12">How BountyBoard Works</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div className="text-center">
                    <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-2xl">1</span>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Browse Bounties</h3>
                    <p className="text-muted-foreground">Explore creative opportunities posted by game studios worldwide</p>
                  </div>
                  <div className="text-center">
                    <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-2xl">2</span>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Apply & Create</h3>
                    <p className="text-muted-foreground">Submit your proposal and work on exciting projects</p>
                  </div>
                  <div className="text-center">
                    <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-2xl">3</span>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Earn & Grow</h3>
                    <p className="text-muted-foreground">Get paid for your work and build your reputation</p>
                  </div>
                </div>
              </div>
            </div>



            {/* Why Choose BountyBoard */}
            <div className="py-16 bg-accent/20">
              <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-center mb-12">Why Choose BountyBoard?</h2>
                <Accordion type="single" collapsible className="max-w-2xl mx-auto">
                  <AccordionItem value="item-1">
                    <AccordionTrigger>Secure Payments</AccordionTrigger>
                    <AccordionContent>
                      All payments are handled through our secure payment system. Funds are held in escrow until work is completed and approved.
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-2">
                    <AccordionTrigger>Talent Verification</AccordionTrigger>
                    <AccordionContent>
                      Our reputation system ensures you're working with verified professionals who have a track record of success.
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-3">
                    <AccordionTrigger>Gamified Experience</AccordionTrigger>
                    <AccordionContent>
                      Earn achievements, level up your profile, and unlock new opportunities as you complete more bounties.
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-4">
                    <AccordionTrigger>Direct Communication</AccordionTrigger>
                    <AccordionContent>
                      Built-in tools for seamless communication between studios and creators throughout the project lifecycle.
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>
            </div>

            {/* Newsletter Section */}
            <div className="py-16">
              <div className="container mx-auto px-4 text-center">
                <h2 className="text-3xl font-bold mb-6">Stay Updated</h2>
                <p className="text-muted-foreground mb-8">Get the latest bounties and platform updates delivered to your inbox</p>
                <div className="flex gap-4 max-w-md mx-auto">
                  <Input type="email" placeholder="Enter your email" className="flex-1" />
                  <Button onClick={() => toast({
                    title: "Thanks for subscribing!",
                    description: "You'll receive our updates soon.",
                  })}>
                    Subscribe
                  </Button>
                </div>
              </div>
            </div>

            {/* Final CTA */}
            <div className="py-16 bg-primary/5">
              <div className="container mx-auto px-4 text-center">
                <h2 className="text-3xl font-bold mb-6">Ready to Join the Creative Revolution?</h2>
                <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
                  Whether you're a studio looking for talent or a creator seeking opportunities, 
                  BountyBoard is your platform for success.
                </p>
                <Link href="/signup">
                  <Button size="lg" className="text-lg">
                    Get Started Now
                  </Button>
                </Link>
              </div>
            </div>

          </div>
        </main>
      </div>
    </>
  );
}