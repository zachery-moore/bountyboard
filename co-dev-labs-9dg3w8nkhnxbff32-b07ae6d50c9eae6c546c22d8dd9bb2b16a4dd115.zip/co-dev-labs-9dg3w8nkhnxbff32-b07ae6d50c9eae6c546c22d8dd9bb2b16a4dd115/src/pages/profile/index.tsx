import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { StudioBankingSetup } from '@/components/StudioBankingSetup';

export default function Profile() {
  const { user } = useAuth();
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [profileData, setProfileData] = useState<any>(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await fetch('/api/profile');
        const data = await response.json();
        setProfileData(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching profile:', error);
        setLoading(false);
      }
    };

    if (user) {
      fetchProfile();
    }
  }, [user]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!profileData) {
    return <div>Profile not found</div>;
  }

  const isCreator = profileData.role === 'CREATOR';

  return (
    <div className="container max-w-4xl py-8">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            onClick={() => router.push('/dashboard')}
          >
            Back to Dashboard
          </Button>
          <h1 className="text-3xl font-bold">Profile</h1>
        </div>
        <Button onClick={() => router.push('/profile/edit')}>Edit Profile</Button>
      </div>

      <div className="space-y-6">
        {/* Basic Information Card */}
        <Card>
          <CardHeader>
            <CardTitle>Basic Information</CardTitle>
          </CardHeader>
          <CardContent className="flex items-start space-x-6">
            <Avatar className="h-24 w-24">
              <AvatarImage src={profileData.avatarUrl} />
              <AvatarFallback>{profileData.name?.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="space-y-2">
              <h2 className="text-2xl font-semibold">{profileData.name}</h2>
              <p className="text-muted-foreground">{profileData.bio}</p>
              <div className="flex items-center space-x-2">
                <Badge>{profileData.role}</Badge>
                <Badge variant="outline">Level {profileData.level}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Card */}
        <Card>
          <CardHeader>
            <CardTitle>Statistics</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">XP</p>
              <p className="text-2xl font-bold">{profileData.xp}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Guild Coins</p>
              <p className="text-2xl font-bold">{profileData.guildCoins}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">
                {isCreator ? 'Quests Completed' : 'Quests Posted'}
              </p>
              <p className="text-2xl font-bold">
                {isCreator
                  ? profileData.profileData?.questsCompleted
                  : profileData.profileData?.questsPosted}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Role-specific Information Card */}
        <Card>
          <CardHeader>
            <CardTitle>{isCreator ? 'Creator Details' : 'Studio Details'}</CardTitle>
          </CardHeader>
          <CardContent>
            {isCreator ? (
              <div className="space-y-4">
                {profileData.profileData?.title && (
                  <div>
                    <p className="text-sm text-muted-foreground">Professional Title</p>
                    <p className="font-medium">{profileData.profileData.title}</p>
                  </div>
                )}
                {profileData.profileData?.specialties?.length > 0 && (
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Specialties</p>
                    <div className="flex flex-wrap gap-2">
                      {profileData.profileData.specialties.map((specialty: string) => (
                        <Badge key={specialty} variant="secondary">
                          {specialty.replace('_', ' ')}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                <div>
                  <p className="text-sm text-muted-foreground">Availability</p>
                  <Badge variant={profileData.profileData?.availability ? "success" : "secondary"}>
                    {profileData.profileData?.availability ? 'Available for Work' : 'Not Available'}
                  </Badge>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {profileData.profileData?.studioName && (
                  <div>
                    <p className="text-sm text-muted-foreground">Studio Name</p>
                    <p className="font-medium">{profileData.profileData.studioName}</p>
                  </div>
                )}
                {profileData.profileData?.website && (
                  <div>
                    <p className="text-sm text-muted-foreground">Website</p>
                    <a
                      href={profileData.profileData.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-500 hover:underline"
                    >
                      {profileData.profileData.website}
                    </a>
                  </div>
                )}
                {profileData.profileData?.description && (
                  <div>
                    <p className="text-sm text-muted-foreground">Description</p>
                    <p>{profileData.profileData.description}</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Banking Setup for Studios */}
        {!isCreator && <StudioBankingSetup />}

        {/* Achievements Card */}
        {profileData.achievements?.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Achievements</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {profileData.achievements.map((achievement: any) => (
                  <div
                    key={achievement.achievement.id}
                    className="p-4 border rounded-lg flex items-center space-x-3"
                  >
                    <span className="text-2xl">{achievement.achievement.icon}</span>
                    <div>
                      <p className="font-medium">{achievement.achievement.title}</p>
                      <p className="text-sm text-muted-foreground">
                        {achievement.achievement.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}