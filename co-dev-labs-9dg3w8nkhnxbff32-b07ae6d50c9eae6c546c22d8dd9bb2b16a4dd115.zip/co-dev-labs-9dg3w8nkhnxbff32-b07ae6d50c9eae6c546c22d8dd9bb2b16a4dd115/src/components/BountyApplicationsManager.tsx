import { useState, useEffect } from 'react'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { format } from 'date-fns'

interface Application {
  id: string
  status: string
  coverLetter: string
  createdAt: string
  applicant: {
    name: string
    profile: {
      title: string
      averageRating: number
      bountiesCompleted: number
    }
  }
}

interface BountyApplicationsManagerProps {
  bountyId: string
  onApplicationUpdate?: () => void
}

export function BountyApplicationsManager({ bountyId, onApplicationUpdate }: BountyApplicationsManagerProps) {
  const [applications, setApplications] = useState<Application[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    fetchApplications()
  }, [bountyId])

  const fetchApplications = async () => {
    try {
      const response = await fetch(`/api/bounties/${bountyId}/applications`)
      if (response.ok) {
        const data = await response.json()
        setApplications(data.filter((app: Application) => app.status === 'PENDING'))
      }
    } catch (error) {
      console.error('Error fetching applications:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleApplicationAction = async (applicationId: string, status: 'ACCEPTED' | 'REJECTED') => {
    try {
      const response = await fetch(`/api/bounties/applications/${applicationId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status }),
      })

      if (!response.ok) {
        throw new Error('Failed to update application')
      }

      toast({
        title: `Application ${status.toLowerCase()}`,
        description: `The application has been ${status.toLowerCase()} successfully.`,
      })

      fetchApplications()
      onApplicationUpdate?.()
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update application status",
      })
    }
  }

  if (isLoading) {
    return <div>Loading applications...</div>
  }

  if (applications.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Applications</CardTitle>
          <CardDescription>No pending applications for this bounty</CardDescription>
        </CardHeader>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Applications</CardTitle>
        <CardDescription>Manage applications for this bounty</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {applications.map((application) => (
            <Card key={application.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{application.applicant.name}</CardTitle>
                    <CardDescription>{application.applicant.profile.title}</CardDescription>
                  </div>
                  <Badge>{application.status}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium">Cover Letter</h4>
                    <p className="mt-1 text-sm text-muted-foreground">{application.coverLetter}</p>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">
                        Applied on {format(new Date(application.createdAt), 'PPP')}
                      </p>
                      <p className="text-sm">
                        Rating: ⭐ {application.applicant.profile.averageRating.toFixed(1)} | 
                        Completed: 🎯 {application.applicant.profile.bountiesCompleted}
                      </p>
                    </div>
                    <div className="space-x-2">
                      <Button
                        variant="destructive"
                        onClick={() => handleApplicationAction(application.id, 'REJECTED')}
                      >
                        Reject
                      </Button>
                      <Button
                        variant="default"
                        onClick={() => handleApplicationAction(application.id, 'ACCEPTED')}
                      >
                        Accept
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}