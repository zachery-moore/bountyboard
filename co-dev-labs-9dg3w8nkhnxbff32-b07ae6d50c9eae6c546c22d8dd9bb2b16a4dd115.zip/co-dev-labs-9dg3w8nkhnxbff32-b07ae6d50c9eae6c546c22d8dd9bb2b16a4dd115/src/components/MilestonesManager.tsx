import { useState, useEffect } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

interface Milestone {
  id: string
  title: string
  description: string
  amount: number
  dueDate: string
  status: string
  order: number
  payments: Payment[]
}

interface Payment {
  id: string
  amount: number
  status: string
  processedAt: string | null
}

interface MilestonesManagerProps {
  bountyId: string
  isStudio: boolean
  totalBudget: number
  remainingBudget: number
}

export default function MilestonesManager({ bountyId, isStudio, totalBudget, remainingBudget }: MilestonesManagerProps) {
  const [milestones, setMilestones] = useState<Milestone[]>([])
  const [isAddingMilestone, setIsAddingMilestone] = useState(false)
  const [newMilestone, setNewMilestone] = useState({
    title: '',
    description: '',
    amount: 0,
    dueDate: '',
  })
  const { user } = useAuth()

  useEffect(() => {
    fetchMilestones()
  }, [bountyId])

  const fetchMilestones = async () => {
    try {
      const response = await fetch(`/api/bounties/${bountyId}/milestones`)
      const data = await response.json()
      setMilestones(data)
    } catch (error) {
      console.error('Failed to fetch milestones:', error)
    }
  }

  const handleAddMilestone = async () => {
    try {
      const response = await fetch(`/api/bounties/${bountyId}/milestones`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newMilestone),
      })

      if (response.ok) {
        setIsAddingMilestone(false)
        setNewMilestone({
          title: '',
          description: '',
          amount: 0,
          dueDate: '',
        })
        fetchMilestones()
      } else {
        const error = await response.json()
        console.error('Failed to add milestone:', error)
      }
    } catch (error) {
      console.error('Failed to add milestone:', error)
    }
  }

  const handlePayment = async (milestoneId: string, amount: number) => {
    try {
      const response = await fetch(`/api/bounties/${bountyId}/payments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          milestoneId,
          amount,
          description: `Payment for milestone ${milestoneId}`,
        }),
      })

      if (response.ok) {
        fetchMilestones()
      } else {
        const error = await response.json()
        console.error('Failed to process payment:', error)
      }
    } catch (error) {
      console.error('Failed to process payment:', error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PENDING':
        return 'bg-yellow-500'
      case 'IN_PROGRESS':
        return 'bg-blue-500'
      case 'COMPLETED':
        return 'bg-green-500'
      case 'APPROVED':
        return 'bg-green-700'
      case 'REJECTED':
        return 'bg-red-500'
      default:
        return 'bg-gray-500'
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Milestones</h2>
          <p className="text-sm text-gray-500">
            Total Budget: ${totalBudget} | Remaining: ${remainingBudget}
          </p>
        </div>
        {isStudio && (
          <Dialog open={isAddingMilestone} onOpenChange={setIsAddingMilestone}>
            <DialogTrigger asChild>
              <Button>Add Milestone</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Milestone</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={newMilestone.title}
                    onChange={(e) =>
                      setNewMilestone({ ...newMilestone, title: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newMilestone.description}
                    onChange={(e) =>
                      setNewMilestone({ ...newMilestone, description: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="amount">Amount ($)</Label>
                  <Input
                    id="amount"
                    type="number"
                    value={newMilestone.amount}
                    onChange={(e) =>
                      setNewMilestone({
                        ...newMilestone,
                        amount: parseFloat(e.target.value),
                      })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="dueDate">Due Date</Label>
                  <Input
                    id="dueDate"
                    type="date"
                    value={newMilestone.dueDate}
                    onChange={(e) =>
                      setNewMilestone({ ...newMilestone, dueDate: e.target.value })
                    }
                  />
                </div>
                <Button onClick={handleAddMilestone}>Create Milestone</Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="grid gap-4">
        {milestones.map((milestone) => (
          <Card key={milestone.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>{milestone.title}</CardTitle>
                  <CardDescription>Due: {new Date(milestone.dueDate).toLocaleDateString()}</CardDescription>
                </div>
                <Badge className={getStatusColor(milestone.status)}>{milestone.status}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="mb-4">{milestone.description}</p>
              <div className="flex justify-between items-center">
                <p className="font-semibold">Amount: ${milestone.amount}</p>
                {isStudio && milestone.status === 'COMPLETED' && !milestone.payments.length && (
                  <Button onClick={() => handlePayment(milestone.id, milestone.amount)}>
                    Process Payment
                  </Button>
                )}
              </div>
              {milestone.payments.length > 0 && (
                <div className="mt-2">
                  <p className="text-sm text-gray-500">
                    Payment processed on{' '}
                    {new Date(milestone.payments[0].processedAt || '').toLocaleDateString()}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}