import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface Challenge {
  id: string;
  progress: number;
  completed: boolean;
  completedAt: string | null;
  challenge: {
    title: string;
    description: string;
    xpReward: number;
    coinReward: number;
    requirement: number;
  };
}

export function DailyChallenges() {
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    const fetchChallenges = async () => {
      try {
        const response = await fetch('/api/daily-challenges');
        if (!response.ok) throw new Error('Failed to fetch challenges');
        const data = await response.json();
        setChallenges(data);
      } catch (error) {
        toast({
          title: 'Error',
          description: 'Failed to load daily challenges',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchChallenges();
    }
  }, [user, toast]);

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Daily Challenges</CardTitle>
          <CardDescription>Loading your challenges...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Daily Challenges</CardTitle>
        <CardDescription>Complete challenges to earn XP and coins!</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {challenges.map((challenge) => (
          <div key={challenge.id} className="space-y-2">
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-medium">{challenge.challenge.title}</h4>
                <p className="text-sm text-muted-foreground">
                  {challenge.challenge.description}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium">
                  {challenge.challenge.xpReward} XP
                </p>
                <p className="text-sm text-muted-foreground">
                  {challenge.challenge.coinReward} coins
                </p>
              </div>
            </div>
            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>
                  {challenge.progress} / {challenge.challenge.requirement}
                </span>
              </div>
              <Progress
                value={(challenge.progress / challenge.challenge.requirement) * 100}
                className="h-2"
              />
            </div>
            {challenge.completed && (
              <p className="text-sm text-green-600 dark:text-green-400">
                Completed! 🎉
              </p>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}