import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Progress } from "@/components/ui/progress"

interface FinancialStats {
  totalSpent: number
  monthlyBudget: number
  activePayments: number
  completedPayments: number
  recentTransactions: Array<{
    id: string
    amount: number
    status: string
    bountyTitle: string
    creatorName: string
    date: string
  }>
  monthlySpending: Array<{
    month: string
    amount: number
  }>
}

interface StudioFinancialDashboardProps {
  stats: FinancialStats
}

export function StudioFinancialDashboard({ stats }: StudioFinancialDashboardProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount)
  }

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      completed: "bg-green-500",
      pending: "bg-yellow-500",
      failed: "bg-red-500",
      processing: "bg-blue-500"
    }
    return colors[status.toLowerCase()] || "bg-gray-500"
  }

  const calculateBudgetProgress = () => {
    return (stats.totalSpent / stats.monthlyBudget) * 100
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Monthly Budget</CardTitle>
            <CardDescription>Budget utilization this month</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Spent: {formatCurrency(stats.totalSpent)}</span>
                <span>Budget: {formatCurrency(stats.monthlyBudget)}</span>
              </div>
              <Progress value={calculateBudgetProgress()} className="h-2" />
              <p className="text-sm text-muted-foreground">
                {Math.round(calculateBudgetProgress())}% of budget used
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Active Payments</CardTitle>
            <CardDescription>Ongoing transactions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{stats.activePayments}</div>
            <p className="text-sm text-muted-foreground">
              {stats.completedPayments} payments completed this month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Monthly Overview</CardTitle>
            <CardDescription>Payment trends</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[60px] flex items-end justify-between gap-2">
              {stats.monthlySpending.map((month) => (
                <div
                  key={month.month}
                  className="bg-primary/10 rounded-sm w-full"
                  style={{
                    height: `${(month.amount / stats.monthlyBudget) * 100}%`,
                  }}
                  title={`${month.month}: ${formatCurrency(month.amount)}`}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
          <CardDescription>Latest payment activities</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[300px] pr-4">
            <div className="space-y-4">
              {stats.recentTransactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="flex items-center justify-between p-4 border rounded-lg"
                >
                  <div className="space-y-1">
                    <p className="font-medium">{transaction.bountyTitle}</p>
                    <p className="text-sm text-muted-foreground">
                      To: {transaction.creatorName}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(transaction.date).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="text-right space-y-1">
                    <p className="font-medium">{formatCurrency(transaction.amount)}</p>
                    <Badge className={getStatusColor(transaction.status)}>
                      {transaction.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  )
}