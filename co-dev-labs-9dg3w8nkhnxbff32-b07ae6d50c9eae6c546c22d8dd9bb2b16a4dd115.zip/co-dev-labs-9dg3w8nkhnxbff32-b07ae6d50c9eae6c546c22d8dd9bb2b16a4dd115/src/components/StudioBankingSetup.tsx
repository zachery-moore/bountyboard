import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Loader2 } from 'lucide-react';

interface BankingStatus {
  isSetup: boolean;
  lastFourBank?: string | null;
  status: 'not_started' | 'incomplete' | 'pending' | 'active';
}

export function StudioBankingSetup() {
  const [loading, setLoading] = useState(false);
  const [bankingStatus, setBankingStatus] = useState<BankingStatus | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchBankingStatus = async () => {
    try {
      setError(null);
      const response = await fetch('/api/studio/banking-status');
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.details || data.error || 'Failed to fetch banking status');
      }
      const data = await response.json();
      setBankingStatus(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch banking status');
    }
  };

  const handleSetupBanking = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/studio/setup-banking', {
        method: 'POST',
      });
      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error);
      } else if (data.url) {
        window.location.href = data.url;
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to initiate banking setup');
    } finally {
      setLoading(false);
    }
  };

  // Fetch banking status when component mounts
  useEffect(() => {
    fetchBankingStatus();
  }, []);

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'active':
        return 'success';
      case 'pending':
        return 'warning';
      case 'incomplete':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  const getStatusDisplay = (status: string) => {
    switch (status) {
      case 'active':
        return 'Active';
      case 'pending':
        return 'Pending Verification';
      case 'incomplete':
        return 'Setup Incomplete';
      case 'not_started':
        return 'Not Set Up';
      default:
        return 'Unknown';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Banking Information</CardTitle>
        <CardDescription>
          Manage your studio&apos;s banking details for receiving payments
        </CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {bankingStatus ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium">Status</p>
                <Badge variant={getStatusBadgeVariant(bankingStatus.status)}>
                  {getStatusDisplay(bankingStatus.status)}
                </Badge>
              </div>
              {bankingStatus.lastFourBank && (
                <div className="space-y-1">
                  <p className="text-sm font-medium">Bank Account</p>
                  <p className="text-sm">****{bankingStatus.lastFourBank}</p>
                </div>
              )}
            </div>

            {bankingStatus.status !== 'pending' && (
              <Button
                onClick={handleSetupBanking}
                disabled={loading}
                className="w-full"
              >
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {bankingStatus.isSetup ? 'Update Banking Details' : 'Set Up Banking'}
              </Button>
            )}
          </div>
        ) : (
          <div className="flex justify-center py-4">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        )}
      </CardContent>
    </Card>
  );
}