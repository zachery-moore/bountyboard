import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { PaymentForm } from './PaymentForm';

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!);

export function StudioPaymentSetup() {
  const { user } = useAuth();
  const [clientSecret, setClientSecret] = useState<string>();
  const [error, setError] = useState<string>();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const setupPayment = async () => {
    setLoading(true);
    setError(undefined);
    
    try {
      const response = await fetch('/api/payments/setup-intent', {
        method: 'POST',
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Failed to set up payment method');
      }
      
      setClientSecret(data.clientSecret);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSetupSuccess = () => {
    setSuccess(true);
    setClientSecret(undefined);
  };

  if (!user) return null;

  return (
    <Card className="p-6">
      <h2 className="text-2xl font-bold mb-4">Payment Setup</h2>
      
      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      {success && (
        <Alert className="mb-4">
          <AlertDescription>Payment method successfully set up!</AlertDescription>
        </Alert>
      )}
      
      {!clientSecret && !success && (
        <div>
          <p className="mb-4">
            To create bounties, you need to set up a payment method first. This ensures smooth
            payment processing when working with creators.
          </p>
          <Button onClick={setupPayment} disabled={loading}>
            {loading ? 'Setting up...' : 'Set Up Payment Method'}
          </Button>
        </div>
      )}
      
      {clientSecret && (
        <Elements stripe={stripePromise} options={{ clientSecret }}>
          <PaymentForm 
            mode="setup"
            onSuccess={handleSetupSuccess}
            onError={(msg) => setError(msg)}
          />
        </Elements>
      )}
    </Card>
  );
}