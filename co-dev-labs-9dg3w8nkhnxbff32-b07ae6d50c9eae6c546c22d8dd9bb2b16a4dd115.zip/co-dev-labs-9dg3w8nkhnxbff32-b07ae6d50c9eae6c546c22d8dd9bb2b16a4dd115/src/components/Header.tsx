import { useContext } from 'react';
import { useRouter } from 'next/router';
import { AuthContext } from '@/contexts/AuthContext';
import Logo from '@/components/Logo';
import { Button } from "@/components/ui/button";

const Header = () => {
  const { user, initializing, signOut } = useContext(AuthContext);
  const router = useRouter();

  return (
    <header className="w-full">
      <div className="flex justify-between items-center py-4 px-4 sm:px-6 lg:px-8">
        <div className="flex items-center space-x-6">
          <div className="cursor-pointer" onClick={() => router.push("/")}>
            <Logo />
          </div>
          {user && (
            <nav className="hidden md:flex space-x-4">
              <Button
                variant="ghost"
                onClick={() => router.push("/bounties")}
              >
                Bounties
              </Button>
              <Button
                variant="ghost"
                onClick={() => router.push("/dashboard")}
              >
                Dashboard
              </Button>
            </nav>
          )}
        </div>
        {!initializing && (
          <div className="flex items-center space-x-4">
            {user ? (
              <Button 
                onClick={() => {
                  signOut();
                  router.push('/');
                }}
                variant="default"
                size="default"
              >
                Log out
              </Button>
            ) : (
              <Button 
                onClick={() => router.push("/login")}
                variant="default"
                size="default"
              >
                Login
              </Button>
            )}
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;