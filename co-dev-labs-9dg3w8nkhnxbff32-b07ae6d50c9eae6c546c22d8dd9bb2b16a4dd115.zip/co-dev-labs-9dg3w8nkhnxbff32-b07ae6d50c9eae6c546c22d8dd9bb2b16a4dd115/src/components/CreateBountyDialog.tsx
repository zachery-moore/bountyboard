import { Button } from "@/components/ui/button"
import { StudioPaymentSetup } from "./StudioPaymentSetup"
import { useEffect } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { useState } from "react"
import { useToast } from "@/components/ui/use-toast"

const SKILL_CATEGORIES = [
  "CONCEPT_ART",
  "CHARACTER_DESIGN",
  "ENVIRONMENT_ART",
  "SOUND_DESIGN",
  "MUSIC_COMPOSITION",
  "UI_DESIGN",
  "GAME_PROGRAMMING",
  "NARRATIVE_DESIGN",
  "ANIMATION",
  "VFX",
  "MARKETING"
]

const DIFFICULTY_LEVELS = [
  "EASY",
  "MEDIUM",
  "HARD",
  "LEGENDARY"
]

export function CreateBountyDialog() {
  const { toast } = useToast()
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [hasPaymentMethod, setHasPaymentMethod] = useState(false)
  const [checkingPayment, setCheckingPayment] = useState(true)

  useEffect(() => {
    const checkPaymentMethod = async () => {
      if (!open) return;
      
      setCheckingPayment(true);
      try {
        const response = await fetch('/api/studio/payment-method');
        const data = await response.json();
        setHasPaymentMethod(data.hasPaymentMethod);
        
        if (!data.hasPaymentMethod) {
          let errorMessage = "Please complete your studio setup. ";
          if (data.bankingStatus !== 'active') {
            errorMessage += "Banking information needs to be verified. ";
          }
          if (data.paymentMethodStatus !== 'ACTIVE') {
            errorMessage += "Payment method needs to be added.";
          }
          toast({
            variant: "destructive",
            title: "Setup Required",
            description: errorMessage,
          });
        }
      } catch (error) {
        console.error('Error checking payment method:', error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to check payment method status",
        });
      } finally {
        setCheckingPayment(false);
      }
    };

    checkPaymentMethod();
  }, [open, toast]);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    difficulty: "",
    monetaryReward: "",
    coinReward: "",
    totalBudget: "",
    deadline: "",
    maxAssignees: "1",
    requirements: "",
    deliverables: ""
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      if (!hasPaymentMethod) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Please set up your payment method first",
        })
        return
      }

      const response = await fetch("/api/bounties", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: formData.title.trim(),
          description: formData.description.trim(),
          category: formData.category,
          difficulty: formData.difficulty,
          monetaryReward: formData.monetaryReward ? parseFloat(formData.monetaryReward) : 0,
          coinReward: formData.coinReward ? parseInt(formData.coinReward) : 0,
          deadline: new Date(formData.deadline).toISOString(),
          maxAssignees: formData.maxAssignees ? parseInt(formData.maxAssignees) : 1,
          requirements: { details: formData.requirements.trim() },
          deliverables: formData.deliverables
            .split('\n')
            .map(item => item.trim())
            .filter(item => item !== '')
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to create bounty")
      }

      toast({
        title: "Success!",
        description: "Your bounty has been created.",
      })
      setOpen(false)
      setFormData({
        title: "",
        description: "",
        category: "",
        difficulty: "",
        monetaryReward: "",
        coinReward: "",
        deadline: "",
        maxAssignees: "1",
        requirements: "",
        deliverables: ""
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create bounty. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg">Create New Bounty</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Create New Bounty</DialogTitle>
            <DialogDescription>
              Post a new quest for creators to take on. Be specific about your requirements and rewards.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Enter bounty title"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe your bounty in detail"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="category">Category</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {SKILL_CATEGORIES.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category.replace(/_/g, " ")}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="difficulty">Difficulty</Label>
                <Select
                  value={formData.difficulty}
                  onValueChange={(value) => setFormData({ ...formData, difficulty: value })}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select difficulty" />
                  </SelectTrigger>
                  <SelectContent>
                    {DIFFICULTY_LEVELS.map((level) => (
                      <SelectItem key={level} value={level}>
                        {level}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="monetaryReward">Monetary Reward ($)</Label>
                <Input
                  id="monetaryReward"
                  type="number"
                  min="0"
                  value={formData.monetaryReward}
                  onChange={(e) => setFormData({ ...formData, monetaryReward: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="coinReward">Coin Reward</Label>
                <Input
                  id="coinReward"
                  type="number"
                  min="0"
                  value={formData.coinReward}
                  onChange={(e) => setFormData({ ...formData, coinReward: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="totalBudget">Total Budget ($)</Label>
                <Input
                  id="totalBudget"
                  type="number"
                  min="0"
                  value={formData.totalBudget}
                  onChange={(e) => setFormData({ ...formData, totalBudget: e.target.value })}
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="deadline">Deadline</Label>
                <Input
                  id="deadline"
                  type="datetime-local"
                  value={formData.deadline}
                  onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="maxAssignees">Max Assignees</Label>
                <Input
                  id="maxAssignees"
                  type="number"
                  min="1"
                  value={formData.maxAssignees}
                  onChange={(e) => setFormData({ ...formData, maxAssignees: e.target.value })}
                  required
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="requirements">Requirements</Label>
              <Textarea
                id="requirements"
                value={formData.requirements}
                onChange={(e) => setFormData({ ...formData, requirements: e.target.value })}
                placeholder="List your specific requirements"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="deliverables">Deliverables (one per line)</Label>
              <Textarea
                id="deliverables"
                value={formData.deliverables}
                onChange={(e) => setFormData({ ...formData, deliverables: e.target.value })}
                placeholder="Enter each deliverable on a new line"
                required
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" disabled={loading}>
              {loading ? "Creating..." : "Create Bounty"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}