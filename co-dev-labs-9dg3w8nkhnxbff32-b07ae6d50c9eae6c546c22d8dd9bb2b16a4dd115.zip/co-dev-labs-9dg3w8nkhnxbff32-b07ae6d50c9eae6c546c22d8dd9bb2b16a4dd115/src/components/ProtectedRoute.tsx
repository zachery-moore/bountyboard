import { useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '@/contexts/AuthContext';

const publicRoutes = ['/', '/login', '/signup', '/forgot-password', '/magic-link-login', '/auth/callback', '/reset-password'];

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, isLoading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!router.isReady || isLoading) return;

    const handleNavigation = async () => {
      // If user is not authenticated and tries to access protected route
      if (!user && !publicRoutes.includes(router.pathname)) {
        const currentPath = router.asPath;
        if (currentPath !== '/login') {
          sessionStorage.setItem('redirectAfterLogin', currentPath);
          await router.replace('/login');
        }
        return;
      }

      // If user is authenticated and tries to access auth routes
      if (user && publicRoutes.includes(router.pathname) && router.pathname !== '/') {
        const redirectUrl = sessionStorage.getItem('redirectAfterLogin') || '/dashboard';
        sessionStorage.removeItem('redirectAfterLogin');
        if (router.pathname !== redirectUrl) {
          await router.replace(redirectUrl);
        }
      }
    };

    handleNavigation();
  }, [user, isLoading, router.pathname, router.isReady, router]);

  // Show loading state
  if (isLoading || !router.isReady) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  // Allow access to public routes even when not authenticated
  if (!user && publicRoutes.includes(router.pathname)) {
    return <>{children}</>;
  }

  // Show loading for protected routes while not authenticated
  if (!user && !publicRoutes.includes(router.pathname)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  // User is authenticated or route is public
  return <>{children}</>;
};

export default ProtectedRoute;