import { useState } from 'react';
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { loadStripe } from '@stripe/stripe-js';
import {
  Elements,
  PaymentElement,
  useStripe,
  useElements,
} from '@stripe/react-stripe-js';

if (!process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY) {
  throw new Error('Missing Stripe Publishable Key');
}

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY);

interface PaymentFormProps {
  mode?: 'payment' | 'setup';
  clientSecret?: string;
  amount?: number;
  onSuccess: () => void;
  onError?: (message: string) => void;
  onCancel?: () => void;
}

const CheckoutForm = ({ mode = 'payment', amount, onSuccess, onError, onCancel }: Omit<PaymentFormProps, 'clientSecret'>) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      if (mode === 'setup') {
        const { error, setupIntent } = await stripe.confirmSetup({
          elements,
          redirect: 'if_required',
        });

        if (error) {
          onError?.(error.message || 'Setup failed');
          toast({
            variant: "destructive",
            title: "Setup failed",
            description: error.message,
          });
        } else if (setupIntent.status === 'succeeded') {
          toast({
            title: "Setup successful",
            description: "Your payment method has been saved.",
          });
          onSuccess();
        }
      } else {
        const { error, paymentIntent } = await stripe.confirmPayment({
          elements,
          redirect: 'if_required',
        });

        if (error) {
          onError?.(error.message || 'Payment failed');
          toast({
            variant: "destructive",
            title: "Payment failed",
            description: error.message,
          });
        } else if (paymentIntent.status === 'succeeded') {
          toast({
            title: "Payment successful",
            description: "Your payment has been processed successfully.",
          });
          onSuccess();
        }
      }
    } catch (err: any) {
      const message = err.message || "An error occurred during processing";
      onError?.(message);
      toast({
        variant: "destructive",
        title: "Error",
        description: message,
      });
    }

    setIsProcessing(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <PaymentElement />
      <div className="flex justify-end space-x-2">
        {onCancel && (
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isProcessing}
          >
            Cancel
          </Button>
        )}
        <Button
          type="submit"
          disabled={!stripe || isProcessing}
        >
          {isProcessing 
            ? "Processing..." 
            : mode === 'setup' 
              ? "Save Payment Method"
              : `Pay $${amount}`
          }
        </Button>
      </div>
    </form>
  );
};

export const PaymentForm = ({ mode = 'payment', clientSecret, amount, onSuccess, onError, onCancel }: PaymentFormProps) => {
  if (!clientSecret) {
    return null;
  }

  const options = {
    clientSecret,
    appearance: {
      theme: 'stripe',
    },
  };

  const content = (
    <Card className="p-4">
      <Elements stripe={stripePromise} options={options}>
        <CheckoutForm
          mode={mode}
          amount={amount}
          onSuccess={onSuccess}
          onError={onError}
          onCancel={onCancel}
        />
      </Elements>
    </Card>
  );

  if (onCancel) {
    return (
      <Dialog open={true} onOpenChange={() => onCancel()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {mode === 'setup' ? 'Set Up Payment Method' : 'Complete Payment'}
            </DialogTitle>
            <DialogDescription>
              {mode === 'setup'
                ? 'Please enter your payment details to save for future transactions.'
                : 'Please enter your payment details to complete the transaction.'
              }
            </DialogDescription>
          </DialogHeader>
          {content}
        </DialogContent>
      </Dialog>
    );
  }

  return content;
};