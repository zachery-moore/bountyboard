import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";

interface Achievement {
  id: string;
  title: string;
  description: string;
  xpReward: number;
  coinReward: number;
  icon: string;
  isSecret: boolean;
  unlocked: boolean;
  unlockedAt?: Date;
}

export function AchievementsDisplay() {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAchievements = async () => {
      try {
        const response = await fetch('/api/achievements');
        if (response.ok) {
          const data = await response.json();
          setAchievements(data);
        }
      } catch (error) {
        console.error('Error fetching achievements:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAchievements();
  }, []);

  const calculateProgress = () => {
    if (achievements.length === 0) return 0;
    const unlockedCount = achievements.filter(a => a.unlocked).length;
    return (unlockedCount / achievements.length) * 100;
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Achievements</CardTitle>
          <CardDescription>Loading achievements...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          Achievements
          <Badge variant="secondary">
            {achievements.filter(a => a.unlocked).length}/{achievements.length}
          </Badge>
        </CardTitle>
        <CardDescription>
          Track your progress and earn rewards
        </CardDescription>
        <Progress value={calculateProgress()} className="h-2" />
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-4">
            {achievements.map((achievement) => (
              <Card
                key={achievement.id}
                className={`relative overflow-hidden transition-all duration-300 ${
                  achievement.unlocked
                    ? 'border-primary'
                    : 'opacity-75 hover:opacity-100'
                }`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center rounded-full bg-primary/10">
                      {achievement.icon}
                    </div>
                    <div className="flex-grow">
                      <h4 className="font-semibold flex items-center gap-2">
                        {achievement.title}
                        {achievement.unlocked && (
                          <Badge variant="success" className="ml-2">
                            Unlocked
                          </Badge>
                        )}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {achievement.description}
                      </p>
                      {achievement.unlocked && achievement.unlockedAt && (
                        <p className="text-xs text-muted-foreground mt-1">
                          Unlocked on {new Date(achievement.unlockedAt).toLocaleDateString()}
                        </p>
                      )}
                      <div className="flex items-center gap-4 mt-2">
                        <Badge variant="outline">+{achievement.xpReward} XP</Badge>
                        <Badge variant="outline">+{achievement.coinReward} 🪙</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}